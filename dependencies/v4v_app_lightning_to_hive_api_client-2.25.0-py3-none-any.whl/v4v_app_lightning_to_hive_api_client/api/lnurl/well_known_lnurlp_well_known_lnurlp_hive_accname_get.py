from http import HTTPStatus
from typing import Any, Dict, Optional, Union

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.http_validation_error import HTTPValidationError
from ...models.lnurl_currency import LnurlCurrency
from ...models.lnurl_pay_response_comment import LnurlPayResponseComment
from ...types import UNSET, Response, Unset


def _get_kwargs(
    hive_accname: str,
    *,
    no_image: Union[Unset, bool] = False,
    currency: Union[Unset, LnurlCurrency] = LnurlCurrency.HIVE,
) -> Dict[str, Any]:
    params: Dict[str, Any] = {}

    params["no_image"] = no_image

    json_currency: Union[Unset, str] = UNSET
    if not isinstance(currency, Unset):
        json_currency = currency.value

    params["currency"] = json_currency

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: Dict[str, Any] = {
        "method": "get",
        "url": f"/.well-known/lnurlp/{hive_accname}",
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: Union[AuthenticatedClient, Client], response: httpx.Response
) -> Optional[Union[HTTPValidationError, LnurlPayResponseComment]]:
    if response.status_code == HTTPStatus.OK:
        response_200 = LnurlPayResponseComment.from_dict(response.json())

        return response_200
    if response.status_code == HTTPStatus.UNPROCESSABLE_ENTITY:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422
    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: Union[AuthenticatedClient, Client], response: httpx.Response
) -> Response[Union[HTTPValidationError, LnurlPayResponseComment]]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    hive_accname: str,
    *,
    client: Union[AuthenticatedClient, Client],
    no_image: Union[Unset, bool] = False,
    currency: Union[Unset, LnurlCurrency] = LnurlCurrency.HIVE,
) -> Response[Union[HTTPValidationError, LnurlPayResponseComment]]:
    """Well Known Lnurlp

     Return the LUNRLp response to send funds to this Hive account
    Specs: https://github.com/fiatjaf/lnurl-rfc/blob/luds/06.md

    There is an exception when handling the `SERVER_ACCOUNT_NAME@domain.name`
    where the `domain.name` is whatever the `LNURL_BASE_URL` is pointing to.

    This Lightning address will not be formatted for forwarding so any sats sent
    to this will remain on the server.

    Args:
        hive_accname (str): Hive name to get invoice for, must be valid Hive name.
        no_image (Union[Unset, bool]): True to exclude an image in the response,
                                 defaults to False set in server environment Default: False.
        currency (Union[Unset, LnurlCurrency]): Represents the available currencies for LNURL.

            Attributes:
                hive (str): The currency code for Hive.
                hbd (str): The currency code for HBD.
                sats (str): The currency code for sats. Default: LnurlCurrency.HIVE.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Union[HTTPValidationError, LnurlPayResponseComment]]
    """

    kwargs = _get_kwargs(
        hive_accname=hive_accname,
        no_image=no_image,
        currency=currency,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    hive_accname: str,
    *,
    client: Union[AuthenticatedClient, Client],
    no_image: Union[Unset, bool] = False,
    currency: Union[Unset, LnurlCurrency] = LnurlCurrency.HIVE,
) -> Optional[Union[HTTPValidationError, LnurlPayResponseComment]]:
    """Well Known Lnurlp

     Return the LUNRLp response to send funds to this Hive account
    Specs: https://github.com/fiatjaf/lnurl-rfc/blob/luds/06.md

    There is an exception when handling the `SERVER_ACCOUNT_NAME@domain.name`
    where the `domain.name` is whatever the `LNURL_BASE_URL` is pointing to.

    This Lightning address will not be formatted for forwarding so any sats sent
    to this will remain on the server.

    Args:
        hive_accname (str): Hive name to get invoice for, must be valid Hive name.
        no_image (Union[Unset, bool]): True to exclude an image in the response,
                                 defaults to False set in server environment Default: False.
        currency (Union[Unset, LnurlCurrency]): Represents the available currencies for LNURL.

            Attributes:
                hive (str): The currency code for Hive.
                hbd (str): The currency code for HBD.
                sats (str): The currency code for sats. Default: LnurlCurrency.HIVE.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Union[HTTPValidationError, LnurlPayResponseComment]
    """

    return sync_detailed(
        hive_accname=hive_accname,
        client=client,
        no_image=no_image,
        currency=currency,
    ).parsed


async def asyncio_detailed(
    hive_accname: str,
    *,
    client: Union[AuthenticatedClient, Client],
    no_image: Union[Unset, bool] = False,
    currency: Union[Unset, LnurlCurrency] = LnurlCurrency.HIVE,
) -> Response[Union[HTTPValidationError, LnurlPayResponseComment]]:
    """Well Known Lnurlp

     Return the LUNRLp response to send funds to this Hive account
    Specs: https://github.com/fiatjaf/lnurl-rfc/blob/luds/06.md

    There is an exception when handling the `SERVER_ACCOUNT_NAME@domain.name`
    where the `domain.name` is whatever the `LNURL_BASE_URL` is pointing to.

    This Lightning address will not be formatted for forwarding so any sats sent
    to this will remain on the server.

    Args:
        hive_accname (str): Hive name to get invoice for, must be valid Hive name.
        no_image (Union[Unset, bool]): True to exclude an image in the response,
                                 defaults to False set in server environment Default: False.
        currency (Union[Unset, LnurlCurrency]): Represents the available currencies for LNURL.

            Attributes:
                hive (str): The currency code for Hive.
                hbd (str): The currency code for HBD.
                sats (str): The currency code for sats. Default: LnurlCurrency.HIVE.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Union[HTTPValidationError, LnurlPayResponseComment]]
    """

    kwargs = _get_kwargs(
        hive_accname=hive_accname,
        no_image=no_image,
        currency=currency,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    hive_accname: str,
    *,
    client: Union[AuthenticatedClient, Client],
    no_image: Union[Unset, bool] = False,
    currency: Union[Unset, LnurlCurrency] = LnurlCurrency.HIVE,
) -> Optional[Union[HTTPValidationError, LnurlPayResponseComment]]:
    """Well Known Lnurlp

     Return the LUNRLp response to send funds to this Hive account
    Specs: https://github.com/fiatjaf/lnurl-rfc/blob/luds/06.md

    There is an exception when handling the `SERVER_ACCOUNT_NAME@domain.name`
    where the `domain.name` is whatever the `LNURL_BASE_URL` is pointing to.

    This Lightning address will not be formatted for forwarding so any sats sent
    to this will remain on the server.

    Args:
        hive_accname (str): Hive name to get invoice for, must be valid Hive name.
        no_image (Union[Unset, bool]): True to exclude an image in the response,
                                 defaults to False set in server environment Default: False.
        currency (Union[Unset, LnurlCurrency]): Represents the available currencies for LNURL.

            Attributes:
                hive (str): The currency code for Hive.
                hbd (str): The currency code for HBD.
                sats (str): The currency code for sats. Default: LnurlCurrency.HIVE.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Union[HTTPValidationError, LnurlPayResponseComment]
    """

    return (
        await asyncio_detailed(
            hive_accname=hive_accname,
            client=client,
            no_image=no_image,
            currency=currency,
        )
    ).parsed
