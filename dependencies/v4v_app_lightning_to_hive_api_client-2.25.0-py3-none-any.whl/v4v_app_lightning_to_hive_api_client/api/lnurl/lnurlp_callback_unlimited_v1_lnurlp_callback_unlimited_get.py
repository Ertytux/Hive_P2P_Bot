from http import HTTPStatus
from typing import Any, Dict, Optional, Union

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.http_validation_error import HTTPValidationError
from ...models.lnurl_pay_action_response import LnurlPayActionResponse
from ...types import UNSET, Response, Unset


def _get_kwargs(
    *,
    amount: int,
    comment: Union[Unset, str] = "",
    nonce: Union[Unset, str] = "",
) -> Dict[str, Any]:
    params: Dict[str, Any] = {}

    params["amount"] = amount

    params["comment"] = comment

    params["nonce"] = nonce

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: Dict[str, Any] = {
        "method": "get",
        "url": "/v1/lnurlp/callback/unlimited",
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: Union[AuthenticatedClient, Client], response: httpx.Response
) -> Optional[Union[HTTPValidationError, LnurlPayActionResponse]]:
    if response.status_code == HTTPStatus.OK:
        response_200 = LnurlPayActionResponse.from_dict(response.json())

        return response_200
    if response.status_code == HTTPStatus.UNPROCESSABLE_ENTITY:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422
    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: Union[AuthenticatedClient, Client], response: httpx.Response
) -> Response[Union[HTTPValidationError, LnurlPayActionResponse]]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: Union[AuthenticatedClient, Client],
    amount: int,
    comment: Union[Unset, str] = "",
    nonce: Union[Unset, str] = "",
) -> Response[Union[HTTPValidationError, LnurlPayActionResponse]]:
    """Lnurlp Callback Unlimited

     Handles LNURLp callbacks for 10,000,000 sat limit invoices with no
    Hive account to send to.
    Amount must be passed in milisats

    Args:
        amount (int): Amount in milisats
        comment (Union[Unset, str]): Comment to be sent with payment Default: ''.
        nonce (Union[Unset, str]): Nonce to be sent with Lightning Invoice,
                    if left blanc will be generated Default: ''.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Union[HTTPValidationError, LnurlPayActionResponse]]
    """

    kwargs = _get_kwargs(
        amount=amount,
        comment=comment,
        nonce=nonce,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: Union[AuthenticatedClient, Client],
    amount: int,
    comment: Union[Unset, str] = "",
    nonce: Union[Unset, str] = "",
) -> Optional[Union[HTTPValidationError, LnurlPayActionResponse]]:
    """Lnurlp Callback Unlimited

     Handles LNURLp callbacks for 10,000,000 sat limit invoices with no
    Hive account to send to.
    Amount must be passed in milisats

    Args:
        amount (int): Amount in milisats
        comment (Union[Unset, str]): Comment to be sent with payment Default: ''.
        nonce (Union[Unset, str]): Nonce to be sent with Lightning Invoice,
                    if left blanc will be generated Default: ''.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Union[HTTPValidationError, LnurlPayActionResponse]
    """

    return sync_detailed(
        client=client,
        amount=amount,
        comment=comment,
        nonce=nonce,
    ).parsed


async def asyncio_detailed(
    *,
    client: Union[AuthenticatedClient, Client],
    amount: int,
    comment: Union[Unset, str] = "",
    nonce: Union[Unset, str] = "",
) -> Response[Union[HTTPValidationError, LnurlPayActionResponse]]:
    """Lnurlp Callback Unlimited

     Handles LNURLp callbacks for 10,000,000 sat limit invoices with no
    Hive account to send to.
    Amount must be passed in milisats

    Args:
        amount (int): Amount in milisats
        comment (Union[Unset, str]): Comment to be sent with payment Default: ''.
        nonce (Union[Unset, str]): Nonce to be sent with Lightning Invoice,
                    if left blanc will be generated Default: ''.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Union[HTTPValidationError, LnurlPayActionResponse]]
    """

    kwargs = _get_kwargs(
        amount=amount,
        comment=comment,
        nonce=nonce,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: Union[AuthenticatedClient, Client],
    amount: int,
    comment: Union[Unset, str] = "",
    nonce: Union[Unset, str] = "",
) -> Optional[Union[HTTPValidationError, LnurlPayActionResponse]]:
    """Lnurlp Callback Unlimited

     Handles LNURLp callbacks for 10,000,000 sat limit invoices with no
    Hive account to send to.
    Amount must be passed in milisats

    Args:
        amount (int): Amount in milisats
        comment (Union[Unset, str]): Comment to be sent with payment Default: ''.
        nonce (Union[Unset, str]): Nonce to be sent with Lightning Invoice,
                    if left blanc will be generated Default: ''.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Union[HTTPValidationError, LnurlPayActionResponse]
    """

    return (
        await asyncio_detailed(
            client=client,
            amount=amount,
            comment=comment,
            nonce=nonce,
        )
    ).parsed
