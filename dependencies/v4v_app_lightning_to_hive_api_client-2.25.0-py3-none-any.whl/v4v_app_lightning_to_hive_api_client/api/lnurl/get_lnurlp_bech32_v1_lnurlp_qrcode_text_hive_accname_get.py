from http import HTTPStatus
from typing import Any, Dict, Optional, Union

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.get_lnurlp_bech_32v1_lnurlp_qrcode_text_hive_accname_get_response_get_lnurlp_bech_32v1_lnurlp_qrcode_text_hive_accname_get import (
    GetLnurlpBech32V1LnurlpQrcodeTextHiveAccnameGetResponseGetLnurlpBech32V1LnurlpQrcodeTextHiveAccnameGet,
)
from ...models.http_validation_error import HTTPValidationError
from ...models.lnurl_currency import LnurlCurrency
from ...types import UNSET, Response, Unset


def _get_kwargs(
    hive_accname: str,
    *,
    no_image: Union[Unset, bool] = False,
    json: Union[Unset, bool] = True,
    currency: Union[Unset, LnurlCurrency] = LnurlCurrency.HIVE,
) -> Dict[str, Any]:
    params: Dict[str, Any] = {}

    params["no_image"] = no_image

    params["json"] = json

    json_currency: Union[Unset, str] = UNSET
    if not isinstance(currency, Unset):
        json_currency = currency.value

    params["currency"] = json_currency

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: Dict[str, Any] = {
        "method": "get",
        "url": f"/v1/lnurlp/qrcode/text/{hive_accname}",
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: Union[AuthenticatedClient, Client], response: httpx.Response
) -> Optional[
    Union[
        GetLnurlpBech32V1LnurlpQrcodeTextHiveAccnameGetResponseGetLnurlpBech32V1LnurlpQrcodeTextHiveAccnameGet,
        HTTPValidationError,
    ]
]:
    if response.status_code == HTTPStatus.OK:
        response_200 = GetLnurlpBech32V1LnurlpQrcodeTextHiveAccnameGetResponseGetLnurlpBech32V1LnurlpQrcodeTextHiveAccnameGet.from_dict(
            response.json()
        )

        return response_200
    if response.status_code == HTTPStatus.UNPROCESSABLE_ENTITY:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422
    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: Union[AuthenticatedClient, Client], response: httpx.Response
) -> Response[
    Union[
        GetLnurlpBech32V1LnurlpQrcodeTextHiveAccnameGetResponseGetLnurlpBech32V1LnurlpQrcodeTextHiveAccnameGet,
        HTTPValidationError,
    ]
]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    hive_accname: str,
    *,
    client: Union[AuthenticatedClient, Client],
    no_image: Union[Unset, bool] = False,
    json: Union[Unset, bool] = True,
    currency: Union[Unset, LnurlCurrency] = LnurlCurrency.HIVE,
) -> Response[
    Union[
        GetLnurlpBech32V1LnurlpQrcodeTextHiveAccnameGetResponseGetLnurlpBech32V1LnurlpQrcodeTextHiveAccnameGet,
        HTTPValidationError,
    ]
]:
    """Get Lnurlp Bech32

     Return a BECH32 encoded string version of an LNURL or a given Hive account.
    The field `prefix` is usually the best one to use as text to be copied to
    Lightning wallet.

    Args:
        hive_accname (str): Hive name to get invoice for
        no_image (Union[Unset, bool]): Include the flag to exclude an image from the return
            Default: False.
        json (Union[Unset, bool]): Return JSON, if false returns bare text string of BECH32 url
            Default: True.
        currency (Union[Unset, LnurlCurrency]): Represents the available currencies for LNURL.

            Attributes:
                hive (str): The currency code for Hive.
                hbd (str): The currency code for HBD.
                sats (str): The currency code for sats. Default: LnurlCurrency.HIVE.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Union[GetLnurlpBech32V1LnurlpQrcodeTextHiveAccnameGetResponseGetLnurlpBech32V1LnurlpQrcodeTextHiveAccnameGet, HTTPValidationError]]
    """

    kwargs = _get_kwargs(
        hive_accname=hive_accname,
        no_image=no_image,
        json=json,
        currency=currency,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    hive_accname: str,
    *,
    client: Union[AuthenticatedClient, Client],
    no_image: Union[Unset, bool] = False,
    json: Union[Unset, bool] = True,
    currency: Union[Unset, LnurlCurrency] = LnurlCurrency.HIVE,
) -> Optional[
    Union[
        GetLnurlpBech32V1LnurlpQrcodeTextHiveAccnameGetResponseGetLnurlpBech32V1LnurlpQrcodeTextHiveAccnameGet,
        HTTPValidationError,
    ]
]:
    """Get Lnurlp Bech32

     Return a BECH32 encoded string version of an LNURL or a given Hive account.
    The field `prefix` is usually the best one to use as text to be copied to
    Lightning wallet.

    Args:
        hive_accname (str): Hive name to get invoice for
        no_image (Union[Unset, bool]): Include the flag to exclude an image from the return
            Default: False.
        json (Union[Unset, bool]): Return JSON, if false returns bare text string of BECH32 url
            Default: True.
        currency (Union[Unset, LnurlCurrency]): Represents the available currencies for LNURL.

            Attributes:
                hive (str): The currency code for Hive.
                hbd (str): The currency code for HBD.
                sats (str): The currency code for sats. Default: LnurlCurrency.HIVE.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Union[GetLnurlpBech32V1LnurlpQrcodeTextHiveAccnameGetResponseGetLnurlpBech32V1LnurlpQrcodeTextHiveAccnameGet, HTTPValidationError]
    """

    return sync_detailed(
        hive_accname=hive_accname,
        client=client,
        no_image=no_image,
        json=json,
        currency=currency,
    ).parsed


async def asyncio_detailed(
    hive_accname: str,
    *,
    client: Union[AuthenticatedClient, Client],
    no_image: Union[Unset, bool] = False,
    json: Union[Unset, bool] = True,
    currency: Union[Unset, LnurlCurrency] = LnurlCurrency.HIVE,
) -> Response[
    Union[
        GetLnurlpBech32V1LnurlpQrcodeTextHiveAccnameGetResponseGetLnurlpBech32V1LnurlpQrcodeTextHiveAccnameGet,
        HTTPValidationError,
    ]
]:
    """Get Lnurlp Bech32

     Return a BECH32 encoded string version of an LNURL or a given Hive account.
    The field `prefix` is usually the best one to use as text to be copied to
    Lightning wallet.

    Args:
        hive_accname (str): Hive name to get invoice for
        no_image (Union[Unset, bool]): Include the flag to exclude an image from the return
            Default: False.
        json (Union[Unset, bool]): Return JSON, if false returns bare text string of BECH32 url
            Default: True.
        currency (Union[Unset, LnurlCurrency]): Represents the available currencies for LNURL.

            Attributes:
                hive (str): The currency code for Hive.
                hbd (str): The currency code for HBD.
                sats (str): The currency code for sats. Default: LnurlCurrency.HIVE.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Union[GetLnurlpBech32V1LnurlpQrcodeTextHiveAccnameGetResponseGetLnurlpBech32V1LnurlpQrcodeTextHiveAccnameGet, HTTPValidationError]]
    """

    kwargs = _get_kwargs(
        hive_accname=hive_accname,
        no_image=no_image,
        json=json,
        currency=currency,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    hive_accname: str,
    *,
    client: Union[AuthenticatedClient, Client],
    no_image: Union[Unset, bool] = False,
    json: Union[Unset, bool] = True,
    currency: Union[Unset, LnurlCurrency] = LnurlCurrency.HIVE,
) -> Optional[
    Union[
        GetLnurlpBech32V1LnurlpQrcodeTextHiveAccnameGetResponseGetLnurlpBech32V1LnurlpQrcodeTextHiveAccnameGet,
        HTTPValidationError,
    ]
]:
    """Get Lnurlp Bech32

     Return a BECH32 encoded string version of an LNURL or a given Hive account.
    The field `prefix` is usually the best one to use as text to be copied to
    Lightning wallet.

    Args:
        hive_accname (str): Hive name to get invoice for
        no_image (Union[Unset, bool]): Include the flag to exclude an image from the return
            Default: False.
        json (Union[Unset, bool]): Return JSON, if false returns bare text string of BECH32 url
            Default: True.
        currency (Union[Unset, LnurlCurrency]): Represents the available currencies for LNURL.

            Attributes:
                hive (str): The currency code for Hive.
                hbd (str): The currency code for HBD.
                sats (str): The currency code for sats. Default: LnurlCurrency.HIVE.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Union[GetLnurlpBech32V1LnurlpQrcodeTextHiveAccnameGetResponseGetLnurlpBech32V1LnurlpQrcodeTextHiveAccnameGet, HTTPValidationError]
    """

    return (
        await asyncio_detailed(
            hive_accname=hive_accname,
            client=client,
            no_image=no_image,
            json=json,
            currency=currency,
        )
    ).parsed
