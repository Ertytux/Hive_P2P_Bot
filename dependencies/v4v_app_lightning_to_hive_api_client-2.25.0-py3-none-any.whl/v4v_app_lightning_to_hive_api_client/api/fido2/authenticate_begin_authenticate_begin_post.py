from http import HTTPStatus
from typing import Any, Dict, Optional, Union

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.http_validation_error import HTTPValidationError
from ...models.user_verification_requirement import UserVerificationRequirement
from ...types import UNSET, Response, Unset


def _get_kwargs(
    *,
    hive_accname: str,
    client_id: str,
    app_id: Union[Unset, str] = "v4vapp",
    user_verification: Union[Unset, UserVerificationRequirement] = UserVerificationRequirement.PREFERRED,
) -> Dict[str, Any]:
    params: Dict[str, Any] = {}

    params["hive_accname"] = hive_accname

    params["clientId"] = client_id

    params["appId"] = app_id

    json_user_verification: Union[Unset, str] = UNSET
    if not isinstance(user_verification, Unset):
        json_user_verification = user_verification.value

    params["userVerification"] = json_user_verification

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: Dict[str, Any] = {
        "method": "post",
        "url": "/authenticate/begin/",
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: Union[AuthenticatedClient, Client], response: httpx.Response
) -> Optional[Union[Any, HTTPValidationError]]:
    if response.status_code == HTTPStatus.OK:
        response_200 = response.json()
        return response_200
    if response.status_code == HTTPStatus.UNPROCESSABLE_ENTITY:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422
    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: Union[AuthenticatedClient, Client], response: httpx.Response
) -> Response[Union[Any, HTTPValidationError]]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: Union[AuthenticatedClient, Client],
    hive_accname: str,
    client_id: str,
    app_id: Union[Unset, str] = "v4vapp",
    user_verification: Union[Unset, UserVerificationRequirement] = UserVerificationRequirement.PREFERRED,
) -> Response[Union[Any, HTTPValidationError]]:
    """Authenticate Begin

     Begins the authentication process for a user.

    Parameters:
    - hive_accname (str): Hive name to challenge for authentication.
    - clientId (str): ClientId used for authentication.
    - appId (str): AppId used for authentication.
    - userVerification (UserVerificationRequirement): User Verification Requirement.
      If the action is for viewing information, consider using DISCOURAGED.
      If the action is for changing information, consider using REQUIRED or PREFERRED.

    Returns:
    - dict: A dictionary containing the authentication options.

    Raises:
    - HTTPException: If no credentials are found for the given hive_accname.

    Args:
        hive_accname (str): Hive name to challenge for authentication
        client_id (str): ClientId used for authentication
        app_id (Union[Unset, str]): AppId used for authentication Default: 'v4vapp'.
        user_verification (Union[Unset, UserVerificationRequirement]): An enumeration. Default:
            UserVerificationRequirement.PREFERRED.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Union[Any, HTTPValidationError]]
    """

    kwargs = _get_kwargs(
        hive_accname=hive_accname,
        client_id=client_id,
        app_id=app_id,
        user_verification=user_verification,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: Union[AuthenticatedClient, Client],
    hive_accname: str,
    client_id: str,
    app_id: Union[Unset, str] = "v4vapp",
    user_verification: Union[Unset, UserVerificationRequirement] = UserVerificationRequirement.PREFERRED,
) -> Optional[Union[Any, HTTPValidationError]]:
    """Authenticate Begin

     Begins the authentication process for a user.

    Parameters:
    - hive_accname (str): Hive name to challenge for authentication.
    - clientId (str): ClientId used for authentication.
    - appId (str): AppId used for authentication.
    - userVerification (UserVerificationRequirement): User Verification Requirement.
      If the action is for viewing information, consider using DISCOURAGED.
      If the action is for changing information, consider using REQUIRED or PREFERRED.

    Returns:
    - dict: A dictionary containing the authentication options.

    Raises:
    - HTTPException: If no credentials are found for the given hive_accname.

    Args:
        hive_accname (str): Hive name to challenge for authentication
        client_id (str): ClientId used for authentication
        app_id (Union[Unset, str]): AppId used for authentication Default: 'v4vapp'.
        user_verification (Union[Unset, UserVerificationRequirement]): An enumeration. Default:
            UserVerificationRequirement.PREFERRED.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Union[Any, HTTPValidationError]
    """

    return sync_detailed(
        client=client,
        hive_accname=hive_accname,
        client_id=client_id,
        app_id=app_id,
        user_verification=user_verification,
    ).parsed


async def asyncio_detailed(
    *,
    client: Union[AuthenticatedClient, Client],
    hive_accname: str,
    client_id: str,
    app_id: Union[Unset, str] = "v4vapp",
    user_verification: Union[Unset, UserVerificationRequirement] = UserVerificationRequirement.PREFERRED,
) -> Response[Union[Any, HTTPValidationError]]:
    """Authenticate Begin

     Begins the authentication process for a user.

    Parameters:
    - hive_accname (str): Hive name to challenge for authentication.
    - clientId (str): ClientId used for authentication.
    - appId (str): AppId used for authentication.
    - userVerification (UserVerificationRequirement): User Verification Requirement.
      If the action is for viewing information, consider using DISCOURAGED.
      If the action is for changing information, consider using REQUIRED or PREFERRED.

    Returns:
    - dict: A dictionary containing the authentication options.

    Raises:
    - HTTPException: If no credentials are found for the given hive_accname.

    Args:
        hive_accname (str): Hive name to challenge for authentication
        client_id (str): ClientId used for authentication
        app_id (Union[Unset, str]): AppId used for authentication Default: 'v4vapp'.
        user_verification (Union[Unset, UserVerificationRequirement]): An enumeration. Default:
            UserVerificationRequirement.PREFERRED.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Union[Any, HTTPValidationError]]
    """

    kwargs = _get_kwargs(
        hive_accname=hive_accname,
        client_id=client_id,
        app_id=app_id,
        user_verification=user_verification,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: Union[AuthenticatedClient, Client],
    hive_accname: str,
    client_id: str,
    app_id: Union[Unset, str] = "v4vapp",
    user_verification: Union[Unset, UserVerificationRequirement] = UserVerificationRequirement.PREFERRED,
) -> Optional[Union[Any, HTTPValidationError]]:
    """Authenticate Begin

     Begins the authentication process for a user.

    Parameters:
    - hive_accname (str): Hive name to challenge for authentication.
    - clientId (str): ClientId used for authentication.
    - appId (str): AppId used for authentication.
    - userVerification (UserVerificationRequirement): User Verification Requirement.
      If the action is for viewing information, consider using DISCOURAGED.
      If the action is for changing information, consider using REQUIRED or PREFERRED.

    Returns:
    - dict: A dictionary containing the authentication options.

    Raises:
    - HTTPException: If no credentials are found for the given hive_accname.

    Args:
        hive_accname (str): Hive name to challenge for authentication
        client_id (str): ClientId used for authentication
        app_id (Union[Unset, str]): AppId used for authentication Default: 'v4vapp'.
        user_verification (Union[Unset, UserVerificationRequirement]): An enumeration. Default:
            UserVerificationRequirement.PREFERRED.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Union[Any, HTTPValidationError]
    """

    return (
        await asyncio_detailed(
            client=client,
            hive_accname=hive_accname,
            client_id=client_id,
            app_id=app_id,
            user_verification=user_verification,
        )
    ).parsed
