from http import HTTPStatus
from typing import Any, Dict, Optional, Union

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.http_validation_error import HTTPValidationError
from ...models.keysend_response import KeysendResponse
from ...types import Response


def _get_kwargs(
    hive_accname: str,
) -> Dict[str, Any]:
    _kwargs: Dict[str, Any] = {
        "method": "get",
        "url": f"/.well-known/keysend/{hive_accname}",
    }

    return _kwargs


def _parse_response(
    *, client: Union[AuthenticatedClient, Client], response: httpx.Response
) -> Optional[Union[HTTPValidationError, KeysendResponse]]:
    if response.status_code == HTTPStatus.OK:
        response_200 = KeysendResponse.from_dict(response.json())

        return response_200
    if response.status_code == HTTPStatus.UNPROCESSABLE_ENTITY:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422
    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: Union[AuthenticatedClient, Client], response: httpx.Response
) -> Response[Union[HTTPValidationError, KeysendResponse]]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    hive_accname: str,
    *,
    client: Union[AuthenticatedClient, Client],
) -> Response[Union[HTTPValidationError, KeysendResponse]]:
    """Well Known Keysend

     Returns the data needed for a Value Block with node address and customKey
    customValue pir

    Args:
        hive_accname (str): Hive name to get keysend for

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Union[HTTPValidationError, KeysendResponse]]
    """

    kwargs = _get_kwargs(
        hive_accname=hive_accname,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    hive_accname: str,
    *,
    client: Union[AuthenticatedClient, Client],
) -> Optional[Union[HTTPValidationError, KeysendResponse]]:
    """Well Known Keysend

     Returns the data needed for a Value Block with node address and customKey
    customValue pir

    Args:
        hive_accname (str): Hive name to get keysend for

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Union[HTTPValidationError, KeysendResponse]
    """

    return sync_detailed(
        hive_accname=hive_accname,
        client=client,
    ).parsed


async def asyncio_detailed(
    hive_accname: str,
    *,
    client: Union[AuthenticatedClient, Client],
) -> Response[Union[HTTPValidationError, KeysendResponse]]:
    """Well Known Keysend

     Returns the data needed for a Value Block with node address and customKey
    customValue pir

    Args:
        hive_accname (str): Hive name to get keysend for

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Union[HTTPValidationError, KeysendResponse]]
    """

    kwargs = _get_kwargs(
        hive_accname=hive_accname,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    hive_accname: str,
    *,
    client: Union[AuthenticatedClient, Client],
) -> Optional[Union[HTTPValidationError, KeysendResponse]]:
    """Well Known Keysend

     Returns the data needed for a Value Block with node address and customKey
    customValue pir

    Args:
        hive_accname (str): Hive name to get keysend for

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Union[HTTPValidationError, KeysendResponse]
    """

    return (
        await asyncio_detailed(
            hive_accname=hive_accname,
            client=client,
        )
    ).parsed
