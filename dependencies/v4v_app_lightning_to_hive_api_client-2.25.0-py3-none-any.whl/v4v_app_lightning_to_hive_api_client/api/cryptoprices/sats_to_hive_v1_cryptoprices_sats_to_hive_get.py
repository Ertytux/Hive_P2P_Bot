from http import HTTPStatus
from typing import Any, Dict, Optional, Union

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.http_validation_error import HTTPValidationError
from ...models.sats_to_hive_v1_cryptoprices_sats_to_hive_get_response_sats_to_hive_v1_cryptoprices_sats_to_hive_get import (
    SatsToHiveV1CryptopricesSatsToHiveGetResponseSatsToHiveV1CryptopricesSatsToHiveGet,
)
from ...types import UNSET, Response


def _get_kwargs(
    *,
    sats: int,
) -> Dict[str, Any]:
    params: Dict[str, Any] = {}

    params["sats"] = sats

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: Dict[str, Any] = {
        "method": "get",
        "url": "/v1/cryptoprices/sats_to_hive/",
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: Union[AuthenticatedClient, Client], response: httpx.Response
) -> Optional[
    Union[HTTPValidationError, SatsToHiveV1CryptopricesSatsToHiveGetResponseSatsToHiveV1CryptopricesSatsToHiveGet]
]:
    if response.status_code == HTTPStatus.OK:
        response_200 = SatsToHiveV1CryptopricesSatsToHiveGetResponseSatsToHiveV1CryptopricesSatsToHiveGet.from_dict(
            response.json()
        )

        return response_200
    if response.status_code == HTTPStatus.UNPROCESSABLE_ENTITY:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422
    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: Union[AuthenticatedClient, Client], response: httpx.Response
) -> Response[
    Union[HTTPValidationError, SatsToHiveV1CryptopricesSatsToHiveGetResponseSatsToHiveV1CryptopricesSatsToHiveGet]
]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: Union[AuthenticatedClient, Client],
    sats: int,
) -> Response[
    Union[HTTPValidationError, SatsToHiveV1CryptopricesSatsToHiveGetResponseSatsToHiveV1CryptopricesSatsToHiveGet]
]:
    """Sats To Hive

     Returns the amount of Hive or HBD needed to get this amount of sats.

    Args:
        sats (int):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Union[HTTPValidationError, SatsToHiveV1CryptopricesSatsToHiveGetResponseSatsToHiveV1CryptopricesSatsToHiveGet]]
    """

    kwargs = _get_kwargs(
        sats=sats,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: Union[AuthenticatedClient, Client],
    sats: int,
) -> Optional[
    Union[HTTPValidationError, SatsToHiveV1CryptopricesSatsToHiveGetResponseSatsToHiveV1CryptopricesSatsToHiveGet]
]:
    """Sats To Hive

     Returns the amount of Hive or HBD needed to get this amount of sats.

    Args:
        sats (int):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Union[HTTPValidationError, SatsToHiveV1CryptopricesSatsToHiveGetResponseSatsToHiveV1CryptopricesSatsToHiveGet]
    """

    return sync_detailed(
        client=client,
        sats=sats,
    ).parsed


async def asyncio_detailed(
    *,
    client: Union[AuthenticatedClient, Client],
    sats: int,
) -> Response[
    Union[HTTPValidationError, SatsToHiveV1CryptopricesSatsToHiveGetResponseSatsToHiveV1CryptopricesSatsToHiveGet]
]:
    """Sats To Hive

     Returns the amount of Hive or HBD needed to get this amount of sats.

    Args:
        sats (int):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Union[HTTPValidationError, SatsToHiveV1CryptopricesSatsToHiveGetResponseSatsToHiveV1CryptopricesSatsToHiveGet]]
    """

    kwargs = _get_kwargs(
        sats=sats,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: Union[AuthenticatedClient, Client],
    sats: int,
) -> Optional[
    Union[HTTPValidationError, SatsToHiveV1CryptopricesSatsToHiveGetResponseSatsToHiveV1CryptopricesSatsToHiveGet]
]:
    """Sats To Hive

     Returns the amount of Hive or HBD needed to get this amount of sats.

    Args:
        sats (int):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Union[HTTPValidationError, SatsToHiveV1CryptopricesSatsToHiveGetResponseSatsToHiveV1CryptopricesSatsToHiveGet]
    """

    return (
        await asyncio_detailed(
            client=client,
            sats=sats,
        )
    ).parsed
