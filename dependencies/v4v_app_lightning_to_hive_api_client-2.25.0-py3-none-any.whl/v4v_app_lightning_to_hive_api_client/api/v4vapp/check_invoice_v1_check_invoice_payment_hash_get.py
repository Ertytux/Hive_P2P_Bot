from http import HTTPStatus
from typing import Any, Dict, Optional, Union

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.http_validation_error import HTTPValidationError
from ...models.invoice_status import InvoiceStatus
from ...types import UNSET, Response, Unset


def _get_kwargs(
    payment_hash: str,
    *,
    test: Union[Unset, bool] = False,
) -> Dict[str, Any]:
    params: Dict[str, Any] = {}

    params["test"] = test

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: Dict[str, Any] = {
        "method": "get",
        "url": f"/v1/check_invoice/{payment_hash}",
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: Union[AuthenticatedClient, Client], response: httpx.Response
) -> Optional[Union[HTTPValidationError, InvoiceStatus]]:
    if response.status_code == HTTPStatus.OK:
        response_200 = InvoiceStatus.from_dict(response.json())

        return response_200
    if response.status_code == HTTPStatus.UNPROCESSABLE_ENTITY:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422
    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: Union[AuthenticatedClient, Client], response: httpx.Response
) -> Response[Union[HTTPValidationError, InvoiceStatus]]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    payment_hash: str,
    *,
    client: Union[AuthenticatedClient, Client],
    test: Union[Unset, bool] = False,
) -> Response[Union[HTTPValidationError, InvoiceStatus]]:
    r"""Check Invoice

     Check invoice payment status. If an invoice is waiting to be paid you will see:

    ```
    {
        \"settled\": false,
        \"paid\": false,
        \"r_preimage\": \"Nj6lMCK6ECTVtkvC4CIDaxf6xNxcrA8PNxIXo6brDMg=\",
        \"state\": \"OPEN\",
        \"expired\": false
    }
    ```

    Once the invoice is paid:

    ```
    {
        \"settled\": true,
        \"paid\": true,
        \"r_preimage\": \"Nj6lMCK6ECTVtkvC4CIDaxf6xNxcrA8PNxIXo6brDMg=\",
        \"state\": \"SETTLED\",
        \"expired\": false
    }
    ```

    If an invoice expires before payment it will show as `settled : false`
    and `expired: true`.

    Args:
        payment_hash (str): Base64 encoded version of the r_hash (payment_hash as returned when
            creating an invoice)
        test (Union[Unset, bool]):  Default: False.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Union[HTTPValidationError, InvoiceStatus]]
    """

    kwargs = _get_kwargs(
        payment_hash=payment_hash,
        test=test,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    payment_hash: str,
    *,
    client: Union[AuthenticatedClient, Client],
    test: Union[Unset, bool] = False,
) -> Optional[Union[HTTPValidationError, InvoiceStatus]]:
    r"""Check Invoice

     Check invoice payment status. If an invoice is waiting to be paid you will see:

    ```
    {
        \"settled\": false,
        \"paid\": false,
        \"r_preimage\": \"Nj6lMCK6ECTVtkvC4CIDaxf6xNxcrA8PNxIXo6brDMg=\",
        \"state\": \"OPEN\",
        \"expired\": false
    }
    ```

    Once the invoice is paid:

    ```
    {
        \"settled\": true,
        \"paid\": true,
        \"r_preimage\": \"Nj6lMCK6ECTVtkvC4CIDaxf6xNxcrA8PNxIXo6brDMg=\",
        \"state\": \"SETTLED\",
        \"expired\": false
    }
    ```

    If an invoice expires before payment it will show as `settled : false`
    and `expired: true`.

    Args:
        payment_hash (str): Base64 encoded version of the r_hash (payment_hash as returned when
            creating an invoice)
        test (Union[Unset, bool]):  Default: False.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Union[HTTPValidationError, InvoiceStatus]
    """

    return sync_detailed(
        payment_hash=payment_hash,
        client=client,
        test=test,
    ).parsed


async def asyncio_detailed(
    payment_hash: str,
    *,
    client: Union[AuthenticatedClient, Client],
    test: Union[Unset, bool] = False,
) -> Response[Union[HTTPValidationError, InvoiceStatus]]:
    r"""Check Invoice

     Check invoice payment status. If an invoice is waiting to be paid you will see:

    ```
    {
        \"settled\": false,
        \"paid\": false,
        \"r_preimage\": \"Nj6lMCK6ECTVtkvC4CIDaxf6xNxcrA8PNxIXo6brDMg=\",
        \"state\": \"OPEN\",
        \"expired\": false
    }
    ```

    Once the invoice is paid:

    ```
    {
        \"settled\": true,
        \"paid\": true,
        \"r_preimage\": \"Nj6lMCK6ECTVtkvC4CIDaxf6xNxcrA8PNxIXo6brDMg=\",
        \"state\": \"SETTLED\",
        \"expired\": false
    }
    ```

    If an invoice expires before payment it will show as `settled : false`
    and `expired: true`.

    Args:
        payment_hash (str): Base64 encoded version of the r_hash (payment_hash as returned when
            creating an invoice)
        test (Union[Unset, bool]):  Default: False.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Union[HTTPValidationError, InvoiceStatus]]
    """

    kwargs = _get_kwargs(
        payment_hash=payment_hash,
        test=test,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    payment_hash: str,
    *,
    client: Union[AuthenticatedClient, Client],
    test: Union[Unset, bool] = False,
) -> Optional[Union[HTTPValidationError, InvoiceStatus]]:
    r"""Check Invoice

     Check invoice payment status. If an invoice is waiting to be paid you will see:

    ```
    {
        \"settled\": false,
        \"paid\": false,
        \"r_preimage\": \"Nj6lMCK6ECTVtkvC4CIDaxf6xNxcrA8PNxIXo6brDMg=\",
        \"state\": \"OPEN\",
        \"expired\": false
    }
    ```

    Once the invoice is paid:

    ```
    {
        \"settled\": true,
        \"paid\": true,
        \"r_preimage\": \"Nj6lMCK6ECTVtkvC4CIDaxf6xNxcrA8PNxIXo6brDMg=\",
        \"state\": \"SETTLED\",
        \"expired\": false
    }
    ```

    If an invoice expires before payment it will show as `settled : false`
    and `expired: true`.

    Args:
        payment_hash (str): Base64 encoded version of the r_hash (payment_hash as returned when
            creating an invoice)
        test (Union[Unset, bool]):  Default: False.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Union[HTTPValidationError, InvoiceStatus]
    """

    return (
        await asyncio_detailed(
            payment_hash=payment_hash,
            client=client,
            test=test,
        )
    ).parsed
