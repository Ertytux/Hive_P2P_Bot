from http import HTTPStatus
from typing import Any, Dict, Optional, Union

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.http_validation_error import HTTPValidationError
from ...models.invoice_reply import InvoiceReply
from ...models.invoice_reply_q_rcode import InvoiceReplyQRcode
from ...models.lnurl_currency import LnurlCurrency
from ...models.lookup_currency import LookupCurrency
from ...models.new_invoice_hive_get_v1_new_invoice_hive_get_qr_code import NewInvoiceHiveGetV1NewInvoiceHiveGetQrCode
from ...types import UNSET, Response, Unset


def _get_kwargs(
    *,
    hive_accname: str,
    amount: Union[Unset, float] = 1.0,
    currency: Union[Unset, LookupCurrency] = LookupCurrency.HIVE,
    receive_currency: Union[Unset, LnurlCurrency] = LnurlCurrency.HIVE,
    usd_hbd: Union[Unset, bool] = False,
    app_name: Union[Unset, str] = UNSET,
    expiry: Union[Unset, int] = 300,
    message: Union[Unset, str] = "",
    qr_code: Union[Unset, NewInvoiceHiveGetV1NewInvoiceHiveGetQrCode] = NewInvoiceHiveGetV1NewInvoiceHiveGetQrCode.NONE,
) -> Dict[str, Any]:
    params: Dict[str, Any] = {}

    params["hive_accname"] = hive_accname

    params["amount"] = amount

    json_currency: Union[Unset, str] = UNSET
    if not isinstance(currency, Unset):
        json_currency = currency.value

    params["currency"] = json_currency

    json_receive_currency: Union[Unset, str] = UNSET
    if not isinstance(receive_currency, Unset):
        json_receive_currency = receive_currency.value

    params["receive_currency"] = json_receive_currency

    params["usd_hbd"] = usd_hbd

    params["app_name"] = app_name

    params["expiry"] = expiry

    params["message"] = message

    json_qr_code: Union[Unset, str] = UNSET
    if not isinstance(qr_code, Unset):
        json_qr_code = qr_code.value

    params["qr_code"] = json_qr_code

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: Dict[str, Any] = {
        "method": "get",
        "url": "/v1/new_invoice_hive",
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: Union[AuthenticatedClient, Client], response: httpx.Response
) -> Optional[Union[HTTPValidationError, Union["InvoiceReply", "InvoiceReplyQRcode"]]]:
    if response.status_code == HTTPStatus.CREATED:

        def _parse_response_201(data: object) -> Union["InvoiceReply", "InvoiceReplyQRcode"]:
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                response_201_type_0 = InvoiceReplyQRcode.from_dict(data)

                return response_201_type_0
            except:  # noqa: E722
                pass
            if not isinstance(data, dict):
                raise TypeError()
            response_201_type_1 = InvoiceReply.from_dict(data)

            return response_201_type_1

        response_201 = _parse_response_201(response.json())

        return response_201
    if response.status_code == HTTPStatus.UNPROCESSABLE_ENTITY:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422
    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: Union[AuthenticatedClient, Client], response: httpx.Response
) -> Response[Union[HTTPValidationError, Union["InvoiceReply", "InvoiceReplyQRcode"]]]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: Union[AuthenticatedClient, Client],
    hive_accname: str,
    amount: Union[Unset, float] = 1.0,
    currency: Union[Unset, LookupCurrency] = LookupCurrency.HIVE,
    receive_currency: Union[Unset, LnurlCurrency] = LnurlCurrency.HIVE,
    usd_hbd: Union[Unset, bool] = False,
    app_name: Union[Unset, str] = UNSET,
    expiry: Union[Unset, int] = 300,
    message: Union[Unset, str] = "",
    qr_code: Union[Unset, NewInvoiceHiveGetV1NewInvoiceHiveGetQrCode] = NewInvoiceHiveGetV1NewInvoiceHiveGetQrCode.NONE,
) -> Response[Union[HTTPValidationError, Union["InvoiceReply", "InvoiceReplyQRcode"]]]:
    """New Invoice Hive Get

     Generate a new Lightning invoice for a fixed amount of Hive, HBD or USD.

    **NOTE**

    New option: `receive_currency` allows you to receive
                Hive, HBD or sats stored as KeepSats.

    The Old flag `usd_hbd` is deprecated and will be removed in the future.

    This can be paid by almost all Lightning wallets. Funds received will be redirected
    to the Hive user as either HBD or Hive depending on what is asked for. If no valid
    Hive account name is found, the payment can not be routed on.

    Can generate a QR Code as either a png or a base64 encoded png
    within the JSON response.

    To generate your own QR Code, take the `payment_request` field from
    the response, append `lightning:` to the front of the text and generate a QR Code
    with the result.

    **WARNING** Do not use the Pipe character `|` in your message.

    Args:
        hive_accname (str): Hive name to send payment to
        amount (Union[Unset, float]):  Default: 1.0.
        currency (Union[Unset, LookupCurrency]): An enumeration. Default: LookupCurrency.HIVE.
        receive_currency (Union[Unset, LnurlCurrency]): Represents the available currencies for
            LNURL.

            Attributes:
                hive (str): The currency code for Hive.
                hbd (str): The currency code for HBD.
                sats (str): The currency code for sats. Default: LnurlCurrency.HIVE.
        usd_hbd (Union[Unset, bool]): If requesting USD, receive HBD instead of Hive.
                    If set to false, you will get Hive Default: False.
        app_name (Union[Unset, str]): Name of your application calling this api
                    (mostly for internal checks). Can't have the value `string`
        expiry (Union[Unset, int]): Expiry time for the invoice in seconds. Max 600s Default: 300.
        message (Union[Unset, str]): Your message which will be received in your
                    Hive Transfer memo field, don't use the pipe `|` symbol Default: ''.
        qr_code (Union[Unset, NewInvoiceHiveGetV1NewInvoiceHiveGetQrCode]): Return a QR Code as
            either a png file or a base64 encoded png in the JSON response Default:
            NewInvoiceHiveGetV1NewInvoiceHiveGetQrCode.NONE.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Union[HTTPValidationError, Union['InvoiceReply', 'InvoiceReplyQRcode']]]
    """

    kwargs = _get_kwargs(
        hive_accname=hive_accname,
        amount=amount,
        currency=currency,
        receive_currency=receive_currency,
        usd_hbd=usd_hbd,
        app_name=app_name,
        expiry=expiry,
        message=message,
        qr_code=qr_code,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: Union[AuthenticatedClient, Client],
    hive_accname: str,
    amount: Union[Unset, float] = 1.0,
    currency: Union[Unset, LookupCurrency] = LookupCurrency.HIVE,
    receive_currency: Union[Unset, LnurlCurrency] = LnurlCurrency.HIVE,
    usd_hbd: Union[Unset, bool] = False,
    app_name: Union[Unset, str] = UNSET,
    expiry: Union[Unset, int] = 300,
    message: Union[Unset, str] = "",
    qr_code: Union[Unset, NewInvoiceHiveGetV1NewInvoiceHiveGetQrCode] = NewInvoiceHiveGetV1NewInvoiceHiveGetQrCode.NONE,
) -> Optional[Union[HTTPValidationError, Union["InvoiceReply", "InvoiceReplyQRcode"]]]:
    """New Invoice Hive Get

     Generate a new Lightning invoice for a fixed amount of Hive, HBD or USD.

    **NOTE**

    New option: `receive_currency` allows you to receive
                Hive, HBD or sats stored as KeepSats.

    The Old flag `usd_hbd` is deprecated and will be removed in the future.

    This can be paid by almost all Lightning wallets. Funds received will be redirected
    to the Hive user as either HBD or Hive depending on what is asked for. If no valid
    Hive account name is found, the payment can not be routed on.

    Can generate a QR Code as either a png or a base64 encoded png
    within the JSON response.

    To generate your own QR Code, take the `payment_request` field from
    the response, append `lightning:` to the front of the text and generate a QR Code
    with the result.

    **WARNING** Do not use the Pipe character `|` in your message.

    Args:
        hive_accname (str): Hive name to send payment to
        amount (Union[Unset, float]):  Default: 1.0.
        currency (Union[Unset, LookupCurrency]): An enumeration. Default: LookupCurrency.HIVE.
        receive_currency (Union[Unset, LnurlCurrency]): Represents the available currencies for
            LNURL.

            Attributes:
                hive (str): The currency code for Hive.
                hbd (str): The currency code for HBD.
                sats (str): The currency code for sats. Default: LnurlCurrency.HIVE.
        usd_hbd (Union[Unset, bool]): If requesting USD, receive HBD instead of Hive.
                    If set to false, you will get Hive Default: False.
        app_name (Union[Unset, str]): Name of your application calling this api
                    (mostly for internal checks). Can't have the value `string`
        expiry (Union[Unset, int]): Expiry time for the invoice in seconds. Max 600s Default: 300.
        message (Union[Unset, str]): Your message which will be received in your
                    Hive Transfer memo field, don't use the pipe `|` symbol Default: ''.
        qr_code (Union[Unset, NewInvoiceHiveGetV1NewInvoiceHiveGetQrCode]): Return a QR Code as
            either a png file or a base64 encoded png in the JSON response Default:
            NewInvoiceHiveGetV1NewInvoiceHiveGetQrCode.NONE.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Union[HTTPValidationError, Union['InvoiceReply', 'InvoiceReplyQRcode']]
    """

    return sync_detailed(
        client=client,
        hive_accname=hive_accname,
        amount=amount,
        currency=currency,
        receive_currency=receive_currency,
        usd_hbd=usd_hbd,
        app_name=app_name,
        expiry=expiry,
        message=message,
        qr_code=qr_code,
    ).parsed


async def asyncio_detailed(
    *,
    client: Union[AuthenticatedClient, Client],
    hive_accname: str,
    amount: Union[Unset, float] = 1.0,
    currency: Union[Unset, LookupCurrency] = LookupCurrency.HIVE,
    receive_currency: Union[Unset, LnurlCurrency] = LnurlCurrency.HIVE,
    usd_hbd: Union[Unset, bool] = False,
    app_name: Union[Unset, str] = UNSET,
    expiry: Union[Unset, int] = 300,
    message: Union[Unset, str] = "",
    qr_code: Union[Unset, NewInvoiceHiveGetV1NewInvoiceHiveGetQrCode] = NewInvoiceHiveGetV1NewInvoiceHiveGetQrCode.NONE,
) -> Response[Union[HTTPValidationError, Union["InvoiceReply", "InvoiceReplyQRcode"]]]:
    """New Invoice Hive Get

     Generate a new Lightning invoice for a fixed amount of Hive, HBD or USD.

    **NOTE**

    New option: `receive_currency` allows you to receive
                Hive, HBD or sats stored as KeepSats.

    The Old flag `usd_hbd` is deprecated and will be removed in the future.

    This can be paid by almost all Lightning wallets. Funds received will be redirected
    to the Hive user as either HBD or Hive depending on what is asked for. If no valid
    Hive account name is found, the payment can not be routed on.

    Can generate a QR Code as either a png or a base64 encoded png
    within the JSON response.

    To generate your own QR Code, take the `payment_request` field from
    the response, append `lightning:` to the front of the text and generate a QR Code
    with the result.

    **WARNING** Do not use the Pipe character `|` in your message.

    Args:
        hive_accname (str): Hive name to send payment to
        amount (Union[Unset, float]):  Default: 1.0.
        currency (Union[Unset, LookupCurrency]): An enumeration. Default: LookupCurrency.HIVE.
        receive_currency (Union[Unset, LnurlCurrency]): Represents the available currencies for
            LNURL.

            Attributes:
                hive (str): The currency code for Hive.
                hbd (str): The currency code for HBD.
                sats (str): The currency code for sats. Default: LnurlCurrency.HIVE.
        usd_hbd (Union[Unset, bool]): If requesting USD, receive HBD instead of Hive.
                    If set to false, you will get Hive Default: False.
        app_name (Union[Unset, str]): Name of your application calling this api
                    (mostly for internal checks). Can't have the value `string`
        expiry (Union[Unset, int]): Expiry time for the invoice in seconds. Max 600s Default: 300.
        message (Union[Unset, str]): Your message which will be received in your
                    Hive Transfer memo field, don't use the pipe `|` symbol Default: ''.
        qr_code (Union[Unset, NewInvoiceHiveGetV1NewInvoiceHiveGetQrCode]): Return a QR Code as
            either a png file or a base64 encoded png in the JSON response Default:
            NewInvoiceHiveGetV1NewInvoiceHiveGetQrCode.NONE.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Union[HTTPValidationError, Union['InvoiceReply', 'InvoiceReplyQRcode']]]
    """

    kwargs = _get_kwargs(
        hive_accname=hive_accname,
        amount=amount,
        currency=currency,
        receive_currency=receive_currency,
        usd_hbd=usd_hbd,
        app_name=app_name,
        expiry=expiry,
        message=message,
        qr_code=qr_code,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: Union[AuthenticatedClient, Client],
    hive_accname: str,
    amount: Union[Unset, float] = 1.0,
    currency: Union[Unset, LookupCurrency] = LookupCurrency.HIVE,
    receive_currency: Union[Unset, LnurlCurrency] = LnurlCurrency.HIVE,
    usd_hbd: Union[Unset, bool] = False,
    app_name: Union[Unset, str] = UNSET,
    expiry: Union[Unset, int] = 300,
    message: Union[Unset, str] = "",
    qr_code: Union[Unset, NewInvoiceHiveGetV1NewInvoiceHiveGetQrCode] = NewInvoiceHiveGetV1NewInvoiceHiveGetQrCode.NONE,
) -> Optional[Union[HTTPValidationError, Union["InvoiceReply", "InvoiceReplyQRcode"]]]:
    """New Invoice Hive Get

     Generate a new Lightning invoice for a fixed amount of Hive, HBD or USD.

    **NOTE**

    New option: `receive_currency` allows you to receive
                Hive, HBD or sats stored as KeepSats.

    The Old flag `usd_hbd` is deprecated and will be removed in the future.

    This can be paid by almost all Lightning wallets. Funds received will be redirected
    to the Hive user as either HBD or Hive depending on what is asked for. If no valid
    Hive account name is found, the payment can not be routed on.

    Can generate a QR Code as either a png or a base64 encoded png
    within the JSON response.

    To generate your own QR Code, take the `payment_request` field from
    the response, append `lightning:` to the front of the text and generate a QR Code
    with the result.

    **WARNING** Do not use the Pipe character `|` in your message.

    Args:
        hive_accname (str): Hive name to send payment to
        amount (Union[Unset, float]):  Default: 1.0.
        currency (Union[Unset, LookupCurrency]): An enumeration. Default: LookupCurrency.HIVE.
        receive_currency (Union[Unset, LnurlCurrency]): Represents the available currencies for
            LNURL.

            Attributes:
                hive (str): The currency code for Hive.
                hbd (str): The currency code for HBD.
                sats (str): The currency code for sats. Default: LnurlCurrency.HIVE.
        usd_hbd (Union[Unset, bool]): If requesting USD, receive HBD instead of Hive.
                    If set to false, you will get Hive Default: False.
        app_name (Union[Unset, str]): Name of your application calling this api
                    (mostly for internal checks). Can't have the value `string`
        expiry (Union[Unset, int]): Expiry time for the invoice in seconds. Max 600s Default: 300.
        message (Union[Unset, str]): Your message which will be received in your
                    Hive Transfer memo field, don't use the pipe `|` symbol Default: ''.
        qr_code (Union[Unset, NewInvoiceHiveGetV1NewInvoiceHiveGetQrCode]): Return a QR Code as
            either a png file or a base64 encoded png in the JSON response Default:
            NewInvoiceHiveGetV1NewInvoiceHiveGetQrCode.NONE.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Union[HTTPValidationError, Union['InvoiceReply', 'InvoiceReplyQRcode']]
    """

    return (
        await asyncio_detailed(
            client=client,
            hive_accname=hive_accname,
            amount=amount,
            currency=currency,
            receive_currency=receive_currency,
            usd_hbd=usd_hbd,
            app_name=app_name,
            expiry=expiry,
            message=message,
            qr_code=qr_code,
        )
    ).parsed
