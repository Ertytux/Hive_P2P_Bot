from http import HTTPStatus
from typing import Any, Dict, Optional, Union

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.http_validation_error import HTTPValidationError
from ...models.invoice_reply import InvoiceReply
from ...models.new_invoice import NewInvoice
from ...types import Response


def _get_kwargs(
    *,
    body: NewInvoice,
) -> Dict[str, Any]:
    headers: Dict[str, Any] = {}

    _kwargs: Dict[str, Any] = {
        "method": "post",
        "url": "/v1/new_invoice_build",
    }

    _body = body.to_dict()

    _kwargs["json"] = _body
    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: Union[AuthenticatedClient, Client], response: httpx.Response
) -> Optional[Union[HTTPValidationError, InvoiceReply]]:
    if response.status_code == HTTPStatus.CREATED:
        response_201 = InvoiceReply.from_dict(response.json())

        return response_201
    if response.status_code == HTTPStatus.UNPROCESSABLE_ENTITY:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422
    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: Union[AuthenticatedClient, Client], response: httpx.Response
) -> Response[Union[HTTPValidationError, InvoiceReply]]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: Union[AuthenticatedClient, Client],
    body: NewInvoice,
) -> Response[Union[HTTPValidationError, InvoiceReply]]:
    """New Invoice Build

     Generate a new Lightning invoice. This will create a Bolt11 Lightning Invoice which
    can be paid by almost all Lightning wallets. Funds received will be redirected to
    the Hive user as either HBD or Hive depending on what is asked for. If no valid
    Hive account name is found, the payment can not be routed on.

    Builds the Memo field from passed parameters. See `NewInvoiceHive` data structure
    for details. Clean flag enables the calling system to request a memo with ONLY
    the supplied text.

    To generate your own QR Code, take the `payment_request` field from
    the response, append `lightning:` to the front of the text and generate a QR Code
    with the result.

    Args:
        body (NewInvoice): NewInvoice base data model

            ### Critical difference:
            * `NewInvoiceBasic` is a base model which uses *sats* for the `amount`

            * ` NewInvoiceLnurlp` is a derived model which uses *milisats* for `amount`.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Union[HTTPValidationError, InvoiceReply]]
    """

    kwargs = _get_kwargs(
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: Union[AuthenticatedClient, Client],
    body: NewInvoice,
) -> Optional[Union[HTTPValidationError, InvoiceReply]]:
    """New Invoice Build

     Generate a new Lightning invoice. This will create a Bolt11 Lightning Invoice which
    can be paid by almost all Lightning wallets. Funds received will be redirected to
    the Hive user as either HBD or Hive depending on what is asked for. If no valid
    Hive account name is found, the payment can not be routed on.

    Builds the Memo field from passed parameters. See `NewInvoiceHive` data structure
    for details. Clean flag enables the calling system to request a memo with ONLY
    the supplied text.

    To generate your own QR Code, take the `payment_request` field from
    the response, append `lightning:` to the front of the text and generate a QR Code
    with the result.

    Args:
        body (NewInvoice): NewInvoice base data model

            ### Critical difference:
            * `NewInvoiceBasic` is a base model which uses *sats* for the `amount`

            * ` NewInvoiceLnurlp` is a derived model which uses *milisats* for `amount`.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Union[HTTPValidationError, InvoiceReply]
    """

    return sync_detailed(
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    *,
    client: Union[AuthenticatedClient, Client],
    body: NewInvoice,
) -> Response[Union[HTTPValidationError, InvoiceReply]]:
    """New Invoice Build

     Generate a new Lightning invoice. This will create a Bolt11 Lightning Invoice which
    can be paid by almost all Lightning wallets. Funds received will be redirected to
    the Hive user as either HBD or Hive depending on what is asked for. If no valid
    Hive account name is found, the payment can not be routed on.

    Builds the Memo field from passed parameters. See `NewInvoiceHive` data structure
    for details. Clean flag enables the calling system to request a memo with ONLY
    the supplied text.

    To generate your own QR Code, take the `payment_request` field from
    the response, append `lightning:` to the front of the text and generate a QR Code
    with the result.

    Args:
        body (NewInvoice): NewInvoice base data model

            ### Critical difference:
            * `NewInvoiceBasic` is a base model which uses *sats* for the `amount`

            * ` NewInvoiceLnurlp` is a derived model which uses *milisats* for `amount`.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Union[HTTPValidationError, InvoiceReply]]
    """

    kwargs = _get_kwargs(
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: Union[AuthenticatedClient, Client],
    body: NewInvoice,
) -> Optional[Union[HTTPValidationError, InvoiceReply]]:
    """New Invoice Build

     Generate a new Lightning invoice. This will create a Bolt11 Lightning Invoice which
    can be paid by almost all Lightning wallets. Funds received will be redirected to
    the Hive user as either HBD or Hive depending on what is asked for. If no valid
    Hive account name is found, the payment can not be routed on.

    Builds the Memo field from passed parameters. See `NewInvoiceHive` data structure
    for details. Clean flag enables the calling system to request a memo with ONLY
    the supplied text.

    To generate your own QR Code, take the `payment_request` field from
    the response, append `lightning:` to the front of the text and generate a QR Code
    with the result.

    Args:
        body (NewInvoice): NewInvoice base data model

            ### Critical difference:
            * `NewInvoiceBasic` is a base model which uses *sats* for the `amount`

            * ` NewInvoiceLnurlp` is a derived model which uses *milisats* for `amount`.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Union[HTTPValidationError, InvoiceReply]
    """

    return (
        await asyncio_detailed(
            client=client,
            body=body,
        )
    ).parsed
