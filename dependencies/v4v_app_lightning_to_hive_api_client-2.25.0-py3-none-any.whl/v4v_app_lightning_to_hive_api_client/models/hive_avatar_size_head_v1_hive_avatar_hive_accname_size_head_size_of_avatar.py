from enum import Enum


class HiveAvatarSizeHeadV1HiveAvatarHiveAccnameSizeHeadSizeOfAvatar(str, Enum):
    LARGE = "large"
    MEDIUM = "medium"
    SMALL = "small"

    def __str__(self) -> str:
        return str(self.value)
