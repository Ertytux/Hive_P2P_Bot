from typing import TYPE_CHECKING, Any, Dict, List, Type, TypeVar, Union

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.keysend_custom_data import KeysendCustomData


T = TypeVar("T", bound="KeysendResponse")


@_attrs_define
class KeysendResponse:
    """
    Attributes:
        custom_data (List['KeysendCustomData']):
        status (Union[Unset, str]):  Default: 'OK'.
        tag (Union[Unset, str]):  Default: 'keysend'.
        pubkey (Union[Unset, str]):  Default: '0266ad2656c7a19a219d37e82b280046660f4d7f3ae0c00b64a1629de4ea567668'.
    """

    custom_data: List["KeysendCustomData"]
    status: Union[Unset, str] = "OK"
    tag: Union[Unset, str] = "keysend"
    pubkey: Union[Unset, str] = "0266ad2656c7a19a219d37e82b280046660f4d7f3ae0c00b64a1629de4ea567668"
    additional_properties: Dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        custom_data = []
        for custom_data_item_data in self.custom_data:
            custom_data_item = custom_data_item_data.to_dict()
            custom_data.append(custom_data_item)

        status = self.status

        tag = self.tag

        pubkey = self.pubkey

        field_dict: Dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "customData": custom_data,
            }
        )
        if status is not UNSET:
            field_dict["status"] = status
        if tag is not UNSET:
            field_dict["tag"] = tag
        if pubkey is not UNSET:
            field_dict["pubkey"] = pubkey

        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        from ..models.keysend_custom_data import KeysendCustomData

        d = src_dict.copy()
        custom_data = []
        _custom_data = d.pop("customData")
        for custom_data_item_data in _custom_data:
            custom_data_item = KeysendCustomData.from_dict(custom_data_item_data)

            custom_data.append(custom_data_item)

        status = d.pop("status", UNSET)

        tag = d.pop("tag", UNSET)

        pubkey = d.pop("pubkey", UNSET)

        keysend_response = cls(
            custom_data=custom_data,
            status=status,
            tag=tag,
            pubkey=pubkey,
        )

        keysend_response.additional_properties = d
        return keysend_response

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
