from enum import Enum


class AesActionTag(str, Enum):
    AES = "aes"

    def __str__(self) -> str:
        return str(self.value)
