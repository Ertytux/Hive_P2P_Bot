from enum import Enum


class NewInvoiceHiveGetV1NewInvoiceHiveGetQrCode(str, Enum):
    BASE64_PNG = "base64_png"
    NONE = "none"
    PNG = "png"

    def __str__(self) -> str:
        return str(self.value)
