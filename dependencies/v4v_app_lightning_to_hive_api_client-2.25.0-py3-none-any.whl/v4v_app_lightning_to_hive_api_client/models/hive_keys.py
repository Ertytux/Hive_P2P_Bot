from enum import Enum


class HiveKeys(str, Enum):
    ACTIVE = "active"
    MEMO = "memo"
    POSTING = "posting"

    def __str__(self) -> str:
        return str(self.value)
