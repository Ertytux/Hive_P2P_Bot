import datetime
from typing import Any, Dict, List, Type, TypeVar, Union

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from ..types import UNSET, Unset

T = TypeVar("T", bound="InvoiceReplyQRcode")


@_attrs_define
class InvoiceReplyQRcode:
    """Sent back to requests payment_hash is base64 encoded r_hash

    Attributes:
        r_hash (str):
        payment_hash (str):
        payment_addr (str):
        payment_request (str):
        amount (Union[Unset, int]): Invoice amount in sats Default: 0.
        memo (Union[Unset, str]): "a formatted text memo which must include the
                    following two elements:
                    `hive_account_name | message to the hive user`
                    Additionally if the memo includes `#HBD` then
                    HBD will be sent, otherwise Hive is sent. Default: 'hive_accname | message'.
        hive_accname (Union[Unset, str]): Must be a valid Hive name according to regex
        app_name (Union[Unset, str]): Can't have the value `string`
        expiry (Union[Unset, int]): Expiry time for the invoice in seconds. Max 600s Default: 300.
        expires_at (Union[Unset, datetime.datetime]): Expiry time for the invoice in UTC
        qr_code_base64 (Union[Unset, str]): Base64 encoded png file for a QR-code Default: ''.
    """

    r_hash: str
    payment_hash: str
    payment_addr: str
    payment_request: str
    amount: Union[Unset, int] = 0
    memo: Union[Unset, str] = "hive_accname | message"
    hive_accname: Union[Unset, str] = UNSET
    app_name: Union[Unset, str] = UNSET
    expiry: Union[Unset, int] = 300
    expires_at: Union[Unset, datetime.datetime] = UNSET
    qr_code_base64: Union[Unset, str] = ""
    additional_properties: Dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        r_hash = self.r_hash

        payment_hash = self.payment_hash

        payment_addr = self.payment_addr

        payment_request = self.payment_request

        amount = self.amount

        memo = self.memo

        hive_accname = self.hive_accname

        app_name = self.app_name

        expiry = self.expiry

        expires_at: Union[Unset, str] = UNSET
        if not isinstance(self.expires_at, Unset):
            expires_at = self.expires_at.isoformat()

        qr_code_base64 = self.qr_code_base64

        field_dict: Dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "r_hash": r_hash,
                "payment_hash": payment_hash,
                "payment_addr": payment_addr,
                "payment_request": payment_request,
            }
        )
        if amount is not UNSET:
            field_dict["amount"] = amount
        if memo is not UNSET:
            field_dict["memo"] = memo
        if hive_accname is not UNSET:
            field_dict["hive_accname"] = hive_accname
        if app_name is not UNSET:
            field_dict["app_name"] = app_name
        if expiry is not UNSET:
            field_dict["expiry"] = expiry
        if expires_at is not UNSET:
            field_dict["expires_at"] = expires_at
        if qr_code_base64 is not UNSET:
            field_dict["qr_code_base64"] = qr_code_base64

        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        d = src_dict.copy()
        r_hash = d.pop("r_hash")

        payment_hash = d.pop("payment_hash")

        payment_addr = d.pop("payment_addr")

        payment_request = d.pop("payment_request")

        amount = d.pop("amount", UNSET)

        memo = d.pop("memo", UNSET)

        hive_accname = d.pop("hive_accname", UNSET)

        app_name = d.pop("app_name", UNSET)

        expiry = d.pop("expiry", UNSET)

        _expires_at = d.pop("expires_at", UNSET)
        expires_at: Union[Unset, datetime.datetime]
        if isinstance(_expires_at, Unset):
            expires_at = UNSET
        else:
            expires_at = isoparse(_expires_at)

        qr_code_base64 = d.pop("qr_code_base64", UNSET)

        invoice_reply_q_rcode = cls(
            r_hash=r_hash,
            payment_hash=payment_hash,
            payment_addr=payment_addr,
            payment_request=payment_request,
            amount=amount,
            memo=memo,
            hive_accname=hive_accname,
            app_name=app_name,
            expiry=expiry,
            expires_at=expires_at,
            qr_code_base64=qr_code_base64,
        )

        invoice_reply_q_rcode.additional_properties = d
        return invoice_reply_q_rcode

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
