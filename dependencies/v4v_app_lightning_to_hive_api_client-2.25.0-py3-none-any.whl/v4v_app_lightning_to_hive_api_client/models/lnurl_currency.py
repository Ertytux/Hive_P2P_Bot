from enum import Enum


class LnurlCurrency(str, Enum):
    HBD = "hbd"
    HIVE = "hive"
    SATS = "sats"

    def __str__(self) -> str:
        return str(self.value)
