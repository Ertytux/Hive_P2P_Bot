from typing import TYPE_CHECKING, Any, Dict, List, Type, TypeVar, Union

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.keychain_data import KeychainData


T = TypeVar("T", bound="KeychainSignedMessage")


@_attrs_define
class KeychainSignedMessage:
    """Represents a signed message from a keychain.

    Attributes:
        success (bool): Indicates whether the message was successfully signed.
        error (str | None): Error message, if any.
        result (str): The signed message.
        data (KeychainData): Additional data associated with the signed message.
        message (str | None): Optional message associated with the signed message.
        request_id (int | None): Optional request ID associated with the signed message.
        publicKey (str | None): Optional public key associated with the signed message.

        Attributes:
            success (bool):
            result (str):
            data (KeychainData): Represents keychain data for authentication.

                Attributes:
                    type (str, optional): The type of keychain data.
                    username (str): The username associated with the keychain data.
                    message (str): The message associated with the keychain data.
                    method (str, optional): The authentication method.
                    rpc (str, optional): The RPC (Remote Procedure Call) associated
                        with the keychain data.
                    title (str, optional): The title of the keychain data.
                    key (HiveKeys, optional): The Hive key associated with the keychain data.
                    domain (str, optional): The domain associated with the keychain data.
            error (Union[Unset, str]):
            message (Union[Unset, str]):
            request_id (Union[Unset, int]):
            public_key (Union[Unset, str]):
    """

    success: bool
    result: str
    data: "KeychainData"
    error: Union[Unset, str] = UNSET
    message: Union[Unset, str] = UNSET
    request_id: Union[Unset, int] = UNSET
    public_key: Union[Unset, str] = UNSET
    additional_properties: Dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        success = self.success

        result = self.result

        data = self.data.to_dict()

        error = self.error

        message = self.message

        request_id = self.request_id

        public_key = self.public_key

        field_dict: Dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "success": success,
                "result": result,
                "data": data,
            }
        )
        if error is not UNSET:
            field_dict["error"] = error
        if message is not UNSET:
            field_dict["message"] = message
        if request_id is not UNSET:
            field_dict["request_id"] = request_id
        if public_key is not UNSET:
            field_dict["publicKey"] = public_key

        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        from ..models.keychain_data import KeychainData

        d = src_dict.copy()
        success = d.pop("success")

        result = d.pop("result")

        data = KeychainData.from_dict(d.pop("data"))

        error = d.pop("error", UNSET)

        message = d.pop("message", UNSET)

        request_id = d.pop("request_id", UNSET)

        public_key = d.pop("publicKey", UNSET)

        keychain_signed_message = cls(
            success=success,
            result=result,
            data=data,
            error=error,
            message=message,
            request_id=request_id,
            public_key=public_key,
        )

        keychain_signed_message.additional_properties = d
        return keychain_signed_message

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
