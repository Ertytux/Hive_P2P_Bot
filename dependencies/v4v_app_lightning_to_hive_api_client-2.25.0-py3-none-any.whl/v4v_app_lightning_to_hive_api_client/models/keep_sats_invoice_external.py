from typing import Any, Dict, List, Type, TypeVar, Union

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

T = TypeVar("T", bound="KeepSatsInvoiceExternal")


@_attrs_define
class KeepSatsInvoiceExternal:
    """Model for paying a Lightning invoice from keepsats of Hive account.

    Attributes:
        hive_accname_from (str): Hive name SENDING sats.
        memo (str): Memo which includes the Lightning invoice to be paid.

        Attributes:
            memo (str): The Lightning invoice to be paid
            hive_accname_from (Union[Unset, str]): Hive name SENDING sats Default: ''.
            sats (Union[Unset, int]): Amount of sats to transfer (set during processing) Default: 0.
    """

    memo: str
    hive_accname_from: Union[Unset, str] = ""
    sats: Union[Unset, int] = 0
    additional_properties: Dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        memo = self.memo

        hive_accname_from = self.hive_accname_from

        sats = self.sats

        field_dict: Dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "memo": memo,
            }
        )
        if hive_accname_from is not UNSET:
            field_dict["hive_accname_from"] = hive_accname_from
        if sats is not UNSET:
            field_dict["sats"] = sats

        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        d = src_dict.copy()
        memo = d.pop("memo")

        hive_accname_from = d.pop("hive_accname_from", UNSET)

        sats = d.pop("sats", UNSET)

        keep_sats_invoice_external = cls(
            memo=memo,
            hive_accname_from=hive_accname_from,
            sats=sats,
        )

        keep_sats_invoice_external.additional_properties = d
        return keep_sats_invoice_external

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
