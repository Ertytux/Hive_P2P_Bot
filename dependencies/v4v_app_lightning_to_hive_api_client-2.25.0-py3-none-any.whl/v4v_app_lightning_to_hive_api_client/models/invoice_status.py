from typing import Any, Dict, List, Type, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

T = TypeVar("T", bound="InvoiceStatus")


@_attrs_define
class InvoiceStatus:
    """
    Attributes:
        settled (bool): True if invoice has been paid
        paid (bool): True if invoice has been paid
        r_preimage (str):
        state (str):
        expired (bool):
    """

    settled: bool
    paid: bool
    r_preimage: str
    state: str
    expired: bool
    additional_properties: Dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        settled = self.settled

        paid = self.paid

        r_preimage = self.r_preimage

        state = self.state

        expired = self.expired

        field_dict: Dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "settled": settled,
                "paid": paid,
                "r_preimage": r_preimage,
                "state": state,
                "expired": expired,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        d = src_dict.copy()
        settled = d.pop("settled")

        paid = d.pop("paid")

        r_preimage = d.pop("r_preimage")

        state = d.pop("state")

        expired = d.pop("expired")

        invoice_status = cls(
            settled=settled,
            paid=paid,
            r_preimage=r_preimage,
            state=state,
            expired=expired,
        )

        invoice_status.additional_properties = d
        return invoice_status

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
