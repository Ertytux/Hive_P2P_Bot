from typing import TYPE_CHECKING, Any, Dict, List, Type, TypeVar, Union

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.keep_sats_summary import KeepSatsSummary


T = TypeVar("T", bound="KeepSatsUserSummary")


@_attrs_define
class KeepSatsUserSummary:
    """
    Attributes:
        hive_accname (str):
        net_msats (int):
        net_hive (float):
        net_usd (float):
        net_hbd (float):
        summary_transactions (List['KeepSatsSummary']):
        net_sats (int):
        admin (Union[Unset, bool]):  Default: False.
    """

    hive_accname: str
    net_msats: int
    net_hive: float
    net_usd: float
    net_hbd: float
    summary_transactions: List["KeepSatsSummary"]
    net_sats: int
    admin: Union[Unset, bool] = False
    additional_properties: Dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        hive_accname = self.hive_accname

        net_msats = self.net_msats

        net_hive = self.net_hive

        net_usd = self.net_usd

        net_hbd = self.net_hbd

        summary_transactions = []
        for summary_transactions_item_data in self.summary_transactions:
            summary_transactions_item = summary_transactions_item_data.to_dict()
            summary_transactions.append(summary_transactions_item)

        net_sats = self.net_sats

        admin = self.admin

        field_dict: Dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "hive_accname": hive_accname,
                "net_msats": net_msats,
                "net_hive": net_hive,
                "net_usd": net_usd,
                "net_hbd": net_hbd,
                "summary_transactions": summary_transactions,
                "net_sats": net_sats,
            }
        )
        if admin is not UNSET:
            field_dict["admin"] = admin

        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        from ..models.keep_sats_summary import KeepSatsSummary

        d = src_dict.copy()
        hive_accname = d.pop("hive_accname")

        net_msats = d.pop("net_msats")

        net_hive = d.pop("net_hive")

        net_usd = d.pop("net_usd")

        net_hbd = d.pop("net_hbd")

        summary_transactions = []
        _summary_transactions = d.pop("summary_transactions")
        for summary_transactions_item_data in _summary_transactions:
            summary_transactions_item = KeepSatsSummary.from_dict(summary_transactions_item_data)

            summary_transactions.append(summary_transactions_item)

        net_sats = d.pop("net_sats")

        admin = d.pop("admin", UNSET)

        keep_sats_user_summary = cls(
            hive_accname=hive_accname,
            net_msats=net_msats,
            net_hive=net_hive,
            net_usd=net_usd,
            net_hbd=net_hbd,
            summary_transactions=summary_transactions,
            net_sats=net_sats,
            admin=admin,
        )

        keep_sats_user_summary.additional_properties = d
        return keep_sats_user_summary

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
