from enum import Enum


class LnurlPayResponseCommentTag(str, Enum):
    PAYREQUEST = "payRequest"

    def __str__(self) -> str:
        return str(self.value)
