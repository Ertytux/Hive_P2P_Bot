from typing import TYPE_CHECKING, Any, Dict, List, Type, TypeVar, Union

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.keep_sats_summary import KeepSatsSummary
    from ..models.keep_sats_transaction import KeepSatsTransaction


T = TypeVar("T", bound="KeepSatsUser")


@_attrs_define
class KeepSatsUser:
    """Represents a user in the KeepSats application.
    Duplicated in the v4vapi project.

        Attributes:
            hive_accname (str):
            net_msats (int):
            net_hive (float):
            net_usd (float):
            net_hbd (float):
            net_sats (int):
            all_transactions (Union[Unset, List['KeepSatsTransaction']]):
            summary_transactions (Union[Unset, List['KeepSatsSummary']]):
    """

    hive_accname: str
    net_msats: int
    net_hive: float
    net_usd: float
    net_hbd: float
    net_sats: int
    all_transactions: Union[Unset, List["KeepSatsTransaction"]] = UNSET
    summary_transactions: Union[Unset, List["KeepSatsSummary"]] = UNSET
    additional_properties: Dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        hive_accname = self.hive_accname

        net_msats = self.net_msats

        net_hive = self.net_hive

        net_usd = self.net_usd

        net_hbd = self.net_hbd

        net_sats = self.net_sats

        all_transactions: Union[Unset, List[Dict[str, Any]]] = UNSET
        if not isinstance(self.all_transactions, Unset):
            all_transactions = []
            for all_transactions_item_data in self.all_transactions:
                all_transactions_item = all_transactions_item_data.to_dict()
                all_transactions.append(all_transactions_item)

        summary_transactions: Union[Unset, List[Dict[str, Any]]] = UNSET
        if not isinstance(self.summary_transactions, Unset):
            summary_transactions = []
            for summary_transactions_item_data in self.summary_transactions:
                summary_transactions_item = summary_transactions_item_data.to_dict()
                summary_transactions.append(summary_transactions_item)

        field_dict: Dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "hive_accname": hive_accname,
                "net_msats": net_msats,
                "net_hive": net_hive,
                "net_usd": net_usd,
                "net_hbd": net_hbd,
                "net_sats": net_sats,
            }
        )
        if all_transactions is not UNSET:
            field_dict["all_transactions"] = all_transactions
        if summary_transactions is not UNSET:
            field_dict["summary_transactions"] = summary_transactions

        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        from ..models.keep_sats_summary import KeepSatsSummary
        from ..models.keep_sats_transaction import KeepSatsTransaction

        d = src_dict.copy()
        hive_accname = d.pop("hive_accname")

        net_msats = d.pop("net_msats")

        net_hive = d.pop("net_hive")

        net_usd = d.pop("net_usd")

        net_hbd = d.pop("net_hbd")

        net_sats = d.pop("net_sats")

        all_transactions = []
        _all_transactions = d.pop("all_transactions", UNSET)
        for all_transactions_item_data in _all_transactions or []:
            all_transactions_item = KeepSatsTransaction.from_dict(all_transactions_item_data)

            all_transactions.append(all_transactions_item)

        summary_transactions = []
        _summary_transactions = d.pop("summary_transactions", UNSET)
        for summary_transactions_item_data in _summary_transactions or []:
            summary_transactions_item = KeepSatsSummary.from_dict(summary_transactions_item_data)

            summary_transactions.append(summary_transactions_item)

        keep_sats_user = cls(
            hive_accname=hive_accname,
            net_msats=net_msats,
            net_hive=net_hive,
            net_usd=net_usd,
            net_hbd=net_hbd,
            net_sats=net_sats,
            all_transactions=all_transactions,
            summary_transactions=summary_transactions,
        )

        keep_sats_user.additional_properties = d
        return keep_sats_user

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
