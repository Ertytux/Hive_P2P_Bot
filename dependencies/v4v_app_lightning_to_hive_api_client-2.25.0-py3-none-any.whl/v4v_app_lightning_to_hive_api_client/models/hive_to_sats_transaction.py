import datetime
from typing import Any, Dict, List, Type, TypeVar, Union

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from ..types import UNSET, Unset

T = TypeVar("T", bound="HiveToSatsTransaction")


@_attrs_define
class HiveToSatsTransaction:
    """
    Attributes:
        trx_id (str):
        success (bool):
        timestamp (datetime.datetime):
        hive_from (str):
        sats (int):
        fees_msat (int):
        net_hive (float):
        answer_trx_id (Union[Unset, str]):
        reason (Union[Unset, str]):  Default: 'Hive to Sats'.
    """

    trx_id: str
    success: bool
    timestamp: datetime.datetime
    hive_from: str
    sats: int
    fees_msat: int
    net_hive: float
    answer_trx_id: Union[Unset, str] = UNSET
    reason: Union[Unset, str] = "Hive to Sats"
    additional_properties: Dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        trx_id = self.trx_id

        success = self.success

        timestamp = self.timestamp.isoformat()

        hive_from = self.hive_from

        sats = self.sats

        fees_msat = self.fees_msat

        net_hive = self.net_hive

        answer_trx_id = self.answer_trx_id

        reason = self.reason

        field_dict: Dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "trx_id": trx_id,
                "success": success,
                "timestamp": timestamp,
                "hive_from": hive_from,
                "sats": sats,
                "fees_msat": fees_msat,
                "net_hive": net_hive,
            }
        )
        if answer_trx_id is not UNSET:
            field_dict["answer_trx_id"] = answer_trx_id
        if reason is not UNSET:
            field_dict["reason"] = reason

        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        d = src_dict.copy()
        trx_id = d.pop("trx_id")

        success = d.pop("success")

        timestamp = isoparse(d.pop("timestamp"))

        hive_from = d.pop("hive_from")

        sats = d.pop("sats")

        fees_msat = d.pop("fees_msat")

        net_hive = d.pop("net_hive")

        answer_trx_id = d.pop("answer_trx_id", UNSET)

        reason = d.pop("reason", UNSET)

        hive_to_sats_transaction = cls(
            trx_id=trx_id,
            success=success,
            timestamp=timestamp,
            hive_from=hive_from,
            sats=sats,
            fees_msat=fees_msat,
            net_hive=net_hive,
            answer_trx_id=answer_trx_id,
            reason=reason,
        )

        hive_to_sats_transaction.additional_properties = d
        return hive_to_sats_transaction

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
