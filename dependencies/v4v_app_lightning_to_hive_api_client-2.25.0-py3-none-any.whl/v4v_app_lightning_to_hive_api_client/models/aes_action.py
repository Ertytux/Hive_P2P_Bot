from typing import Any, Dict, List, Type, TypeVar, Union

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..models.aes_action_tag import AesActionTag
from ..types import UNSET, Unset

T = TypeVar("T", bound="AesAction")


@_attrs_define
class AesAction:
    """
    Attributes:
        description (str):
        ciphertext (str):
        iv (str):
        tag (Union[Unset, AesActionTag]):  Default: AesActionTag.AES.
    """

    description: str
    ciphertext: str
    iv: str
    tag: Union[Unset, AesActionTag] = AesActionTag.AES
    additional_properties: Dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        description = self.description

        ciphertext = self.ciphertext

        iv = self.iv

        tag: Union[Unset, str] = UNSET
        if not isinstance(self.tag, Unset):
            tag = self.tag.value

        field_dict: Dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "description": description,
                "ciphertext": ciphertext,
                "iv": iv,
            }
        )
        if tag is not UNSET:
            field_dict["tag"] = tag

        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        d = src_dict.copy()
        description = d.pop("description")

        ciphertext = d.pop("ciphertext")

        iv = d.pop("iv")

        _tag = d.pop("tag", UNSET)
        tag: Union[Unset, AesActionTag]
        if isinstance(_tag, Unset):
            tag = UNSET
        else:
            tag = AesActionTag(_tag)

        aes_action = cls(
            description=description,
            ciphertext=ciphertext,
            iv=iv,
            tag=tag,
        )

        aes_action.additional_properties = d
        return aes_action

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
