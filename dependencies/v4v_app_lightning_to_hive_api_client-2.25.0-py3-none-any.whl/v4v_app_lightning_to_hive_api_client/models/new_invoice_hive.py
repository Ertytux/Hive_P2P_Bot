from typing import Any, Dict, List, Type, TypeVar, Union

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

T = TypeVar("T", bound="NewInvoiceHive")


@_attrs_define
class NewInvoiceHive:
    """Invoice class to be used for a fixed Hive or HBD amount quote

    Attributes:
        hive_accname (str): Must be a valid Hive name according to regex
        amount (Union[Unset, int]): Invoice amount in **sats** NOT **milisats** Default: 0.
        app_name (Union[Unset, str]): Can't have the value `string` Default: ''.
        testing (Union[Unset, bool]):  Default: False.
        expiry (Union[Unset, int]): Expiry time for the invoice in seconds. Max 600s Default: 300.
        message (Union[Unset, str]):  Default: ''.
        hbd (Union[Unset, bool]):  Default: False.
        hive_amount (Union[Unset, float]):
                    If multiple amounts are requested, the amount chosen is in order
                    of precedence Hive > HBD > USD > sats Default: 0.0.
        hbd_amount (Union[Unset, float]):
                    If multiple amounts are requested, the amount chosen is in order
                    of precedence Hive > HBD > USD > sats Default: 0.0.
        usd_amount (Union[Unset, float]):
                    If multiple amounts are requested, the amount chosen is in order
                    of precedence Hive > HBD > USD > sats Default: 0.0.
        sats_amount (Union[Unset, int]):
                    If multiple amounts are requested, the amount chosen is in order
                    of precedence Hive > HBD > USD > sats Default: 0.
        qr_image (Union[Unset, bool]): Optionally return a base64 encoded QR code image Default: False.
        unique_id (Union[Unset, str]): Do not send, will be used internally Default: ''.
    """

    hive_accname: str
    amount: Union[Unset, int] = 0
    app_name: Union[Unset, str] = ""
    testing: Union[Unset, bool] = False
    expiry: Union[Unset, int] = 300
    message: Union[Unset, str] = ""
    hbd: Union[Unset, bool] = False
    hive_amount: Union[Unset, float] = 0.0
    hbd_amount: Union[Unset, float] = 0.0
    usd_amount: Union[Unset, float] = 0.0
    sats_amount: Union[Unset, int] = 0
    qr_image: Union[Unset, bool] = False
    unique_id: Union[Unset, str] = ""
    additional_properties: Dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        hive_accname = self.hive_accname

        amount = self.amount

        app_name = self.app_name

        testing = self.testing

        expiry = self.expiry

        message = self.message

        hbd = self.hbd

        hive_amount = self.hive_amount

        hbd_amount = self.hbd_amount

        usd_amount = self.usd_amount

        sats_amount = self.sats_amount

        qr_image = self.qr_image

        unique_id = self.unique_id

        field_dict: Dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "hive_accname": hive_accname,
            }
        )
        if amount is not UNSET:
            field_dict["amount"] = amount
        if app_name is not UNSET:
            field_dict["app_name"] = app_name
        if testing is not UNSET:
            field_dict["testing"] = testing
        if expiry is not UNSET:
            field_dict["expiry"] = expiry
        if message is not UNSET:
            field_dict["message"] = message
        if hbd is not UNSET:
            field_dict["hbd"] = hbd
        if hive_amount is not UNSET:
            field_dict["hive_amount"] = hive_amount
        if hbd_amount is not UNSET:
            field_dict["hbd_amount"] = hbd_amount
        if usd_amount is not UNSET:
            field_dict["usd_amount"] = usd_amount
        if sats_amount is not UNSET:
            field_dict["sats_amount"] = sats_amount
        if qr_image is not UNSET:
            field_dict["qr_image"] = qr_image
        if unique_id is not UNSET:
            field_dict["unique_id"] = unique_id

        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        d = src_dict.copy()
        hive_accname = d.pop("hive_accname")

        amount = d.pop("amount", UNSET)

        app_name = d.pop("app_name", UNSET)

        testing = d.pop("testing", UNSET)

        expiry = d.pop("expiry", UNSET)

        message = d.pop("message", UNSET)

        hbd = d.pop("hbd", UNSET)

        hive_amount = d.pop("hive_amount", UNSET)

        hbd_amount = d.pop("hbd_amount", UNSET)

        usd_amount = d.pop("usd_amount", UNSET)

        sats_amount = d.pop("sats_amount", UNSET)

        qr_image = d.pop("qr_image", UNSET)

        unique_id = d.pop("unique_id", UNSET)

        new_invoice_hive = cls(
            hive_accname=hive_accname,
            amount=amount,
            app_name=app_name,
            testing=testing,
            expiry=expiry,
            message=message,
            hbd=hbd,
            hive_amount=hive_amount,
            hbd_amount=hbd_amount,
            usd_amount=usd_amount,
            sats_amount=sats_amount,
            qr_image=qr_image,
            unique_id=unique_id,
        )

        new_invoice_hive.additional_properties = d
        return new_invoice_hive

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
