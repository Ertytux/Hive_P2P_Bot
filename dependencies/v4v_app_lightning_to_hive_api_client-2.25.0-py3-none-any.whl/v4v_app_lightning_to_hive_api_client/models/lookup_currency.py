from enum import Enum


class LookupCurrency(str, Enum):
    HBD = "HBD"
    HIVE = "HIVE"
    SATS = "SATS"
    USD = "USD"

    def __str__(self) -> str:
        return str(self.value)
