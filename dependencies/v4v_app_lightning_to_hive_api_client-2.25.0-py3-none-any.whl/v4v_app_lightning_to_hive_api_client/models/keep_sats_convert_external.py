from typing import Any, Dict, List, Type, TypeVar, Union

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

T = TypeVar("T", bound="KeepSatsConvertExternal")


@_attrs_define
class KeepSatsConvertExternal:
    """Model for converting KeepSats to Hive or HBD.

    Attributes:
        sats (int): Amount of sats to convert.
        memo (str, optional): Memo to include with the transfer.

        Attributes:
            sats (int): Amount of sats to transfer
            currency (str): Currency to convert to hbd or hive
            memo (Union[Unset, str]): Memo to include with the transfer Default: ''.
    """

    sats: int
    currency: str
    memo: Union[Unset, str] = ""
    additional_properties: Dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        sats = self.sats

        currency = self.currency

        memo = self.memo

        field_dict: Dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "sats": sats,
                "currency": currency,
            }
        )
        if memo is not UNSET:
            field_dict["memo"] = memo

        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        d = src_dict.copy()
        sats = d.pop("sats")

        currency = d.pop("currency")

        memo = d.pop("memo", UNSET)

        keep_sats_convert_external = cls(
            sats=sats,
            currency=currency,
            memo=memo,
        )

        keep_sats_convert_external.additional_properties = d
        return keep_sats_convert_external

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
