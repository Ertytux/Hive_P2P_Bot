from typing import TYPE_CHECKING, Any, Dict, List, Type, TypeVar, Union

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.aes_action import AesAction
    from ..models.lnurl_pay_route_hop import LnurlPayRouteHop
    from ..models.message_action import MessageAction
    from ..models.url_action import UrlAction


T = TypeVar("T", bound="LnurlPayActionResponse")


@_attrs_define
class LnurlPayActionResponse:
    """
    Attributes:
        pr (str):
        success_action (Union['AesAction', 'MessageAction', 'UrlAction', Unset]):
        routes (Union[Unset, List[List['LnurlPayRouteHop']]]):
    """

    pr: str
    success_action: Union["AesAction", "MessageAction", "UrlAction", Unset] = UNSET
    routes: Union[Unset, List[List["LnurlPayRouteHop"]]] = UNSET
    additional_properties: Dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        from ..models.message_action import MessageAction
        from ..models.url_action import UrlAction

        pr = self.pr

        success_action: Union[Dict[str, Any], Unset]
        if isinstance(self.success_action, Unset):
            success_action = UNSET
        elif isinstance(self.success_action, MessageAction):
            success_action = self.success_action.to_dict()
        elif isinstance(self.success_action, UrlAction):
            success_action = self.success_action.to_dict()
        else:
            success_action = self.success_action.to_dict()

        routes: Union[Unset, List[List[Dict[str, Any]]]] = UNSET
        if not isinstance(self.routes, Unset):
            routes = []
            for routes_item_data in self.routes:
                routes_item = []
                for routes_item_item_data in routes_item_data:
                    routes_item_item = routes_item_item_data.to_dict()
                    routes_item.append(routes_item_item)

                routes.append(routes_item)

        field_dict: Dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "pr": pr,
            }
        )
        if success_action is not UNSET:
            field_dict["successAction"] = success_action
        if routes is not UNSET:
            field_dict["routes"] = routes

        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        from ..models.aes_action import AesAction
        from ..models.lnurl_pay_route_hop import LnurlPayRouteHop
        from ..models.message_action import MessageAction
        from ..models.url_action import UrlAction

        d = src_dict.copy()
        pr = d.pop("pr")

        def _parse_success_action(data: object) -> Union["AesAction", "MessageAction", "UrlAction", Unset]:
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                success_action_type_0 = MessageAction.from_dict(data)

                return success_action_type_0
            except:  # noqa: E722
                pass
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                success_action_type_1 = UrlAction.from_dict(data)

                return success_action_type_1
            except:  # noqa: E722
                pass
            if not isinstance(data, dict):
                raise TypeError()
            success_action_type_2 = AesAction.from_dict(data)

            return success_action_type_2

        success_action = _parse_success_action(d.pop("successAction", UNSET))

        routes = []
        _routes = d.pop("routes", UNSET)
        for routes_item_data in _routes or []:
            routes_item = []
            _routes_item = routes_item_data
            for routes_item_item_data in _routes_item:
                routes_item_item = LnurlPayRouteHop.from_dict(routes_item_item_data)

                routes_item.append(routes_item_item)

            routes.append(routes_item)

        lnurl_pay_action_response = cls(
            pr=pr,
            success_action=success_action,
            routes=routes,
        )

        lnurl_pay_action_response.additional_properties = d
        return lnurl_pay_action_response

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
