from typing import Any, Dict, List, Type, TypeVar, Union

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

T = TypeVar("T", bound="AccountCreate")


@_attrs_define
class AccountCreate:
    """
    Attributes:
        account_name (str): The account name for the new account
        client_id (str): ClientId used for authentication
        app_id (Union[Unset, str]): AppId used for authentication Default: 'v4vapp'.
        master_password (Union[Unset, str]): The master password for the new account
        payment_hash (Union[Unset, str]):
                    Base64 encoded version of the r_hash
                    (payment_hash as returned when creating an invoice)

        payment_voucher (Union[Unset, str]):
        r_hash (Union[Unset, str]): The r_hash of the payment hash
        r_preimage (Union[Unset, str]): The preimage of the payment hash
    """

    account_name: str
    client_id: str
    app_id: Union[Unset, str] = "v4vapp"
    master_password: Union[Unset, str] = UNSET
    payment_hash: Union[Unset, str] = UNSET
    payment_voucher: Union[Unset, str] = UNSET
    r_hash: Union[Unset, str] = UNSET
    r_preimage: Union[Unset, str] = UNSET
    additional_properties: Dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        account_name = self.account_name

        client_id = self.client_id

        app_id = self.app_id

        master_password = self.master_password

        payment_hash = self.payment_hash

        payment_voucher = self.payment_voucher

        r_hash = self.r_hash

        r_preimage = self.r_preimage

        field_dict: Dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "accountName": account_name,
                "clientId": client_id,
            }
        )
        if app_id is not UNSET:
            field_dict["appId"] = app_id
        if master_password is not UNSET:
            field_dict["masterPassword"] = master_password
        if payment_hash is not UNSET:
            field_dict["payment_hash"] = payment_hash
        if payment_voucher is not UNSET:
            field_dict["paymentVoucher"] = payment_voucher
        if r_hash is not UNSET:
            field_dict["r_hash"] = r_hash
        if r_preimage is not UNSET:
            field_dict["r_preimage"] = r_preimage

        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        d = src_dict.copy()
        account_name = d.pop("accountName")

        client_id = d.pop("clientId")

        app_id = d.pop("appId", UNSET)

        master_password = d.pop("masterPassword", UNSET)

        payment_hash = d.pop("payment_hash", UNSET)

        payment_voucher = d.pop("paymentVoucher", UNSET)

        r_hash = d.pop("r_hash", UNSET)

        r_preimage = d.pop("r_preimage", UNSET)

        account_create = cls(
            account_name=account_name,
            client_id=client_id,
            app_id=app_id,
            master_password=master_password,
            payment_hash=payment_hash,
            payment_voucher=payment_voucher,
            r_hash=r_hash,
            r_preimage=r_preimage,
        )

        account_create.additional_properties = d
        return account_create

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
