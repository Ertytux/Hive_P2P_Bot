import datetime
from typing import TYPE_CHECKING, Any, Dict, List, Type, TypeVar, Union

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from ..models.keep_sats_reason import KeepSatsReason
from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.keep_sats_transaction import KeepSatsTransaction


T = TypeVar("T", bound="KeepSatsSummary")


@_attrs_define
class KeepSatsSummary:
    """
    Attributes:
        sats (float):
        hive (float):
        usd (float):
        hbd (float):
        msats (int):
        timestamp (datetime.datetime):
        group_id (str):
        details (List['KeepSatsTransaction']):
        reason (Union[Unset, KeepSatsReason]): An enumeration. Default: KeepSatsReason.OTHER.
        reason_str (Union[Unset, str]):
        from_account (Union[Unset, str]):
        to_account (Union[Unset, str]):
    """

    sats: float
    hive: float
    usd: float
    hbd: float
    msats: int
    timestamp: datetime.datetime
    group_id: str
    details: List["KeepSatsTransaction"]
    reason: Union[Unset, KeepSatsReason] = KeepSatsReason.OTHER
    reason_str: Union[Unset, str] = UNSET
    from_account: Union[Unset, str] = UNSET
    to_account: Union[Unset, str] = UNSET
    additional_properties: Dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        sats = self.sats

        hive = self.hive

        usd = self.usd

        hbd = self.hbd

        msats = self.msats

        timestamp = self.timestamp.isoformat()

        group_id = self.group_id

        details = []
        for details_item_data in self.details:
            details_item = details_item_data.to_dict()
            details.append(details_item)

        reason: Union[Unset, str] = UNSET
        if not isinstance(self.reason, Unset):
            reason = self.reason.value

        reason_str = self.reason_str

        from_account = self.from_account

        to_account = self.to_account

        field_dict: Dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "sats": sats,
                "hive": hive,
                "usd": usd,
                "hbd": hbd,
                "msats": msats,
                "timestamp": timestamp,
                "group_id": group_id,
                "details": details,
            }
        )
        if reason is not UNSET:
            field_dict["reason"] = reason
        if reason_str is not UNSET:
            field_dict["reason_str"] = reason_str
        if from_account is not UNSET:
            field_dict["from_account"] = from_account
        if to_account is not UNSET:
            field_dict["to_account"] = to_account

        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        from ..models.keep_sats_transaction import KeepSatsTransaction

        d = src_dict.copy()
        sats = d.pop("sats")

        hive = d.pop("hive")

        usd = d.pop("usd")

        hbd = d.pop("hbd")

        msats = d.pop("msats")

        timestamp = isoparse(d.pop("timestamp"))

        group_id = d.pop("group_id")

        details = []
        _details = d.pop("details")
        for details_item_data in _details:
            details_item = KeepSatsTransaction.from_dict(details_item_data)

            details.append(details_item)

        _reason = d.pop("reason", UNSET)
        reason: Union[Unset, KeepSatsReason]
        if isinstance(_reason, Unset):
            reason = UNSET
        else:
            reason = KeepSatsReason(_reason)

        reason_str = d.pop("reason_str", UNSET)

        from_account = d.pop("from_account", UNSET)

        to_account = d.pop("to_account", UNSET)

        keep_sats_summary = cls(
            sats=sats,
            hive=hive,
            usd=usd,
            hbd=hbd,
            msats=msats,
            timestamp=timestamp,
            group_id=group_id,
            details=details,
            reason=reason,
            reason_str=reason_str,
            from_account=from_account,
            to_account=to_account,
        )

        keep_sats_summary.additional_properties = d
        return keep_sats_summary

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
