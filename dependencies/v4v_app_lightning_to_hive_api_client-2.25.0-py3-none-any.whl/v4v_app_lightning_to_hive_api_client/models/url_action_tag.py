from enum import Enum


class UrlActionTag(str, Enum):
    URL = "url"

    def __str__(self) -> str:
        return str(self.value)
