from typing import Any, Dict, List, Type, TypeVar, Union

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

T = TypeVar("T", bound="KeepSatsTransferResponse")


@_attrs_define
class KeepSatsTransferResponse:
    """Model for returning the response from a transfer of sats from one Hive account to another.

    Attributes:
        success (bool): True if the transfer was successful.
        message (str): Message about the result of the transfer.
        trx_id (str): Transaction ID of the transfer.
        error (Optional[Any]): Optional error information.

        Attributes:
            success (bool): True if the transfer was successful
            message (str): Message about the result of the transfer
            trx_id (str): Transaction ID of the transfer
            error (Union[Unset, Any]):
    """

    success: bool
    message: str
    trx_id: str
    error: Union[Unset, Any] = UNSET
    additional_properties: Dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        success = self.success

        message = self.message

        trx_id = self.trx_id

        error = self.error

        field_dict: Dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "success": success,
                "message": message,
                "trx_id": trx_id,
            }
        )
        if error is not UNSET:
            field_dict["error"] = error

        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        d = src_dict.copy()
        success = d.pop("success")

        message = d.pop("message")

        trx_id = d.pop("trx_id")

        error = d.pop("error", UNSET)

        keep_sats_transfer_response = cls(
            success=success,
            message=message,
            trx_id=trx_id,
            error=error,
        )

        keep_sats_transfer_response.additional_properties = d
        return keep_sats_transfer_response

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
