from typing import Any, Dict, List, Type, TypeVar, Union

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

T = TypeVar("T", bound="AccountCreateResponse")


@_attrs_define
class AccountCreateResponse:
    """
    Attributes:
        status (str):
        message (str):
        account_name (str): The account name for the new account
        master_password (Union[Unset, str]): The master password for the new account
        success (Union[Unset, bool]):  Default: False.
    """

    status: str
    message: str
    account_name: str
    master_password: Union[Unset, str] = UNSET
    success: Union[Unset, bool] = False
    additional_properties: Dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        status = self.status

        message = self.message

        account_name = self.account_name

        master_password = self.master_password

        success = self.success

        field_dict: Dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "status": status,
                "message": message,
                "accountName": account_name,
            }
        )
        if master_password is not UNSET:
            field_dict["masterPassword"] = master_password
        if success is not UNSET:
            field_dict["success"] = success

        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        d = src_dict.copy()
        status = d.pop("status")

        message = d.pop("message")

        account_name = d.pop("accountName")

        master_password = d.pop("masterPassword", UNSET)

        success = d.pop("success", UNSET)

        account_create_response = cls(
            status=status,
            message=message,
            account_name=account_name,
            master_password=master_password,
            success=success,
        )

        account_create_response.additional_properties = d
        return account_create_response

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
