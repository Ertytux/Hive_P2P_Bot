from enum import Enum


class KeepSatsReason(str, Enum):
    BOOST = "Boost"
    CONVERSION = "Conversion"
    DEPOSIT = "Deposit"
    FEE = "Fee"
    INVOICE = "Invoice"
    NOTIFY = "Notify"
    OTHER = "Other"
    STREAMING = "Streaming"
    TRANSFER = "Transfer"
    WITHDRAWAL = "Withdrawal"

    def __str__(self) -> str:
        return str(self.value)
