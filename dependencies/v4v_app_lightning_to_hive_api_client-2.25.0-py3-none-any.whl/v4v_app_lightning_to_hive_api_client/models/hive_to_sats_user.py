from typing import TYPE_CHECKING, Any, Dict, List, Type, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

if TYPE_CHECKING:
    from ..models.hive_to_sats_transaction import HiveToSatsTransaction


T = TypeVar("T", bound="HiveToSatsUser")


@_attrs_define
class HiveToSatsUser:
    """
    Attributes:
        hive_from (str):
        count (int):
        count_success (int):
        net_hive (float):
        total_sats (int):
        total_usd (float):
        hours (int):
        transactions (List['HiveToSatsTransaction']):
    """

    hive_from: str
    count: int
    count_success: int
    net_hive: float
    total_sats: int
    total_usd: float
    hours: int
    transactions: List["HiveToSatsTransaction"]
    additional_properties: Dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        hive_from = self.hive_from

        count = self.count

        count_success = self.count_success

        net_hive = self.net_hive

        total_sats = self.total_sats

        total_usd = self.total_usd

        hours = self.hours

        transactions = []
        for transactions_item_data in self.transactions:
            transactions_item = transactions_item_data.to_dict()
            transactions.append(transactions_item)

        field_dict: Dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "hive_from": hive_from,
                "count": count,
                "count_success": count_success,
                "net_hive": net_hive,
                "total_sats": total_sats,
                "total_USD": total_usd,
                "hours": hours,
                "transactions": transactions,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        from ..models.hive_to_sats_transaction import HiveToSatsTransaction

        d = src_dict.copy()
        hive_from = d.pop("hive_from")

        count = d.pop("count")

        count_success = d.pop("count_success")

        net_hive = d.pop("net_hive")

        total_sats = d.pop("total_sats")

        total_usd = d.pop("total_USD")

        hours = d.pop("hours")

        transactions = []
        _transactions = d.pop("transactions")
        for transactions_item_data in _transactions:
            transactions_item = HiveToSatsTransaction.from_dict(transactions_item_data)

            transactions.append(transactions_item)

        hive_to_sats_user = cls(
            hive_from=hive_from,
            count=count,
            count_success=count_success,
            net_hive=net_hive,
            total_sats=total_sats,
            total_usd=total_usd,
            hours=hours,
            transactions=transactions,
        )

        hive_to_sats_user.additional_properties = d
        return hive_to_sats_user

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
