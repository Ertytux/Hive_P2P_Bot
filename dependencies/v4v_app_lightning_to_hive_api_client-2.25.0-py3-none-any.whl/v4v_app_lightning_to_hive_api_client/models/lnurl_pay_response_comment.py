from typing import Any, Dict, List, Type, TypeVar, Union, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..models.lnurl_pay_response_comment_tag import LnurlPayResponseCommentTag
from ..types import UNSET, Unset

T = TypeVar("T", bound="LnurlPayResponseComment")


@_attrs_define
class LnurlPayResponseComment:
    """Adds the optional comment_allowed field to the LnurlPayResponse
    ref LUD-12: Comments in payRequest.

        Attributes:
            callback (str):
            min_sendable (int):
            max_sendable (int):
            metadata (str):
            tag (Union[Unset, LnurlPayResponseCommentTag]):  Default: LnurlPayResponseCommentTag.PAYREQUEST.
            comment_allowed (Union[Unset, int]): Length of comment which can be sent Default: 1000.
    """

    callback: str
    min_sendable: int
    max_sendable: int
    metadata: str
    tag: Union[Unset, LnurlPayResponseCommentTag] = LnurlPayResponseCommentTag.PAYREQUEST
    comment_allowed: Union[Unset, int] = 1000
    additional_properties: Dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        callback: str
        callback = self.callback

        min_sendable = self.min_sendable

        max_sendable = self.max_sendable

        metadata = self.metadata

        tag: Union[Unset, str] = UNSET
        if not isinstance(self.tag, Unset):
            tag = self.tag.value

        comment_allowed = self.comment_allowed

        field_dict: Dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "callback": callback,
                "minSendable": min_sendable,
                "maxSendable": max_sendable,
                "metadata": metadata,
            }
        )
        if tag is not UNSET:
            field_dict["tag"] = tag
        if comment_allowed is not UNSET:
            field_dict["commentAllowed"] = comment_allowed

        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        d = src_dict.copy()

        def _parse_callback(data: object) -> str:
            return cast(str, data)

        callback = _parse_callback(d.pop("callback"))

        min_sendable = d.pop("minSendable")

        max_sendable = d.pop("maxSendable")

        metadata = d.pop("metadata")

        _tag = d.pop("tag", UNSET)
        tag: Union[Unset, LnurlPayResponseCommentTag]
        if isinstance(_tag, Unset):
            tag = UNSET
        else:
            tag = LnurlPayResponseCommentTag(_tag)

        comment_allowed = d.pop("commentAllowed", UNSET)

        lnurl_pay_response_comment = cls(
            callback=callback,
            min_sendable=min_sendable,
            max_sendable=max_sendable,
            metadata=metadata,
            tag=tag,
            comment_allowed=comment_allowed,
        )

        lnurl_pay_response_comment.additional_properties = d
        return lnurl_pay_response_comment

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
