from enum import Enum


class TrxType(str, Enum):
    BALANCE = "balance"
    FEE = "fee"
    INCOMING_HIVE = "incoming_hive"
    INCOMING_SATS = "incoming_sats"
    OUTGOING_HIVE = "outgoing_hive"
    OUTGOING_SATS = "outgoing_sats"
    TRANSFER = "transfer"

    def __str__(self) -> str:
        return str(self.value)
