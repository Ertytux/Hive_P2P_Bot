import datetime
from typing import TYPE_CHECKING, Any, Dict, List, Type, TypeVar, Union

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.attested_credential_data import AttestedCredentialData


T = TypeVar("T", bound="CredentialDevice")


@_attrs_define
class CredentialDevice:
    """
    Attributes:
        timestamp (datetime.datetime):
        hive_accname (str):
        count (int):
        server_name (str):
        server_url (str):
        last_used (datetime.datetime):
        field_id (Union[Unset, str]):
        acd (Union[Unset, AttestedCredentialData]):
        device_name (Union[Unset, str]):  Default: ''.
        client_id (Union[Unset, str]):  Default: ''.
        app_id (Union[Unset, str]):  Default: ''.
    """

    timestamp: datetime.datetime
    hive_accname: str
    count: int
    server_name: str
    server_url: str
    last_used: datetime.datetime
    field_id: Union[Unset, str] = UNSET
    acd: Union[Unset, "AttestedCredentialData"] = UNSET
    device_name: Union[Unset, str] = ""
    client_id: Union[Unset, str] = ""
    app_id: Union[Unset, str] = ""
    additional_properties: Dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        timestamp = self.timestamp.isoformat()

        hive_accname = self.hive_accname

        count = self.count

        server_name = self.server_name

        server_url = self.server_url

        last_used = self.last_used.isoformat()

        field_id = self.field_id

        acd: Union[Unset, Dict[str, Any]] = UNSET
        if not isinstance(self.acd, Unset):
            acd = self.acd.to_dict()

        device_name = self.device_name

        client_id = self.client_id

        app_id = self.app_id

        field_dict: Dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "timestamp": timestamp,
                "hive_accname": hive_accname,
                "count": count,
                "server_name": server_name,
                "server_url": server_url,
                "last_used": last_used,
            }
        )
        if field_id is not UNSET:
            field_dict["_id"] = field_id
        if acd is not UNSET:
            field_dict["acd"] = acd
        if device_name is not UNSET:
            field_dict["device_name"] = device_name
        if client_id is not UNSET:
            field_dict["client_id"] = client_id
        if app_id is not UNSET:
            field_dict["app_id"] = app_id

        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        from ..models.attested_credential_data import AttestedCredentialData

        d = src_dict.copy()
        timestamp = isoparse(d.pop("timestamp"))

        hive_accname = d.pop("hive_accname")

        count = d.pop("count")

        server_name = d.pop("server_name")

        server_url = d.pop("server_url")

        last_used = isoparse(d.pop("last_used"))

        field_id = d.pop("_id", UNSET)

        _acd = d.pop("acd", UNSET)
        acd: Union[Unset, AttestedCredentialData]
        if isinstance(_acd, Unset):
            acd = UNSET
        else:
            acd = AttestedCredentialData.from_dict(_acd)

        device_name = d.pop("device_name", UNSET)

        client_id = d.pop("client_id", UNSET)

        app_id = d.pop("app_id", UNSET)

        credential_device = cls(
            timestamp=timestamp,
            hive_accname=hive_accname,
            count=count,
            server_name=server_name,
            server_url=server_url,
            last_used=last_used,
            field_id=field_id,
            acd=acd,
            device_name=device_name,
            client_id=client_id,
            app_id=app_id,
        )

        credential_device.additional_properties = d
        return credential_device

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
