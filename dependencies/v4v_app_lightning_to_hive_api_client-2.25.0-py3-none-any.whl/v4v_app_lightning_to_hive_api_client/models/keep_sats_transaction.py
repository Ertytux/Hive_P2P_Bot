import datetime
from typing import Any, Dict, List, Type, TypeVar, Union

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from ..models.keep_sats_reason import KeepSatsReason
from ..models.trx_type import TrxType
from ..types import UNSET, Unset

T = TypeVar("T", bound="KeepSatsTransaction")


@_attrs_define
class KeepSatsTransaction:
    """Represents a transaction in the KeepSats application.
    Duplicated in the v4vapi project.

        Attributes:
            hive_accname (str):
            timestamp (datetime.datetime):
            msats (int):
            sats (int):
            hive (float):
            hbd (float):
            usd (float):
            trx_type (TrxType): Taken from the v4vapi project.
            group_id (str):
            trx_id (Union[Unset, str]):
            add_index (Union[Unset, int]):
            reason (Union[Unset, KeepSatsReason]): An enumeration. Default: KeepSatsReason.OTHER.
            unique_id (Union[Unset, str]):  Default: ''.
            memo (Union[Unset, str]):
            nobroadcast (Union[Unset, bool]):  Default: False.
            hive_accname_from (Union[Unset, str]):
            hive_accname_to (Union[Unset, str]):
            reason_str (Union[Unset, str]):
    """

    hive_accname: str
    timestamp: datetime.datetime
    msats: int
    sats: int
    hive: float
    hbd: float
    usd: float
    trx_type: TrxType
    group_id: str
    trx_id: Union[Unset, str] = UNSET
    add_index: Union[Unset, int] = UNSET
    reason: Union[Unset, KeepSatsReason] = KeepSatsReason.OTHER
    unique_id: Union[Unset, str] = ""
    memo: Union[Unset, str] = UNSET
    nobroadcast: Union[Unset, bool] = False
    hive_accname_from: Union[Unset, str] = UNSET
    hive_accname_to: Union[Unset, str] = UNSET
    reason_str: Union[Unset, str] = UNSET
    additional_properties: Dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        hive_accname = self.hive_accname

        timestamp = self.timestamp.isoformat()

        msats = self.msats

        sats = self.sats

        hive = self.hive

        hbd = self.hbd

        usd = self.usd

        trx_type = self.trx_type.value

        group_id = self.group_id

        trx_id = self.trx_id

        add_index = self.add_index

        reason: Union[Unset, str] = UNSET
        if not isinstance(self.reason, Unset):
            reason = self.reason.value

        unique_id = self.unique_id

        memo = self.memo

        nobroadcast = self.nobroadcast

        hive_accname_from = self.hive_accname_from

        hive_accname_to = self.hive_accname_to

        reason_str = self.reason_str

        field_dict: Dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "hive_accname": hive_accname,
                "timestamp": timestamp,
                "msats": msats,
                "sats": sats,
                "hive": hive,
                "hbd": hbd,
                "usd": usd,
                "trx_type": trx_type,
                "group_id": group_id,
            }
        )
        if trx_id is not UNSET:
            field_dict["trx_id"] = trx_id
        if add_index is not UNSET:
            field_dict["add_index"] = add_index
        if reason is not UNSET:
            field_dict["reason"] = reason
        if unique_id is not UNSET:
            field_dict["unique_id"] = unique_id
        if memo is not UNSET:
            field_dict["memo"] = memo
        if nobroadcast is not UNSET:
            field_dict["nobroadcast"] = nobroadcast
        if hive_accname_from is not UNSET:
            field_dict["hive_accname_from"] = hive_accname_from
        if hive_accname_to is not UNSET:
            field_dict["hive_accname_to"] = hive_accname_to
        if reason_str is not UNSET:
            field_dict["reason_str"] = reason_str

        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        d = src_dict.copy()
        hive_accname = d.pop("hive_accname")

        timestamp = isoparse(d.pop("timestamp"))

        msats = d.pop("msats")

        sats = d.pop("sats")

        hive = d.pop("hive")

        hbd = d.pop("hbd")

        usd = d.pop("usd")

        trx_type = TrxType(d.pop("trx_type"))

        group_id = d.pop("group_id")

        trx_id = d.pop("trx_id", UNSET)

        add_index = d.pop("add_index", UNSET)

        _reason = d.pop("reason", UNSET)
        reason: Union[Unset, KeepSatsReason]
        if isinstance(_reason, Unset):
            reason = UNSET
        else:
            reason = KeepSatsReason(_reason)

        unique_id = d.pop("unique_id", UNSET)

        memo = d.pop("memo", UNSET)

        nobroadcast = d.pop("nobroadcast", UNSET)

        hive_accname_from = d.pop("hive_accname_from", UNSET)

        hive_accname_to = d.pop("hive_accname_to", UNSET)

        reason_str = d.pop("reason_str", UNSET)

        keep_sats_transaction = cls(
            hive_accname=hive_accname,
            timestamp=timestamp,
            msats=msats,
            sats=sats,
            hive=hive,
            hbd=hbd,
            usd=usd,
            trx_type=trx_type,
            group_id=group_id,
            trx_id=trx_id,
            add_index=add_index,
            reason=reason,
            unique_id=unique_id,
            memo=memo,
            nobroadcast=nobroadcast,
            hive_accname_from=hive_accname_from,
            hive_accname_to=hive_accname_to,
            reason_str=reason_str,
        )

        keep_sats_transaction.additional_properties = d
        return keep_sats_transaction

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
