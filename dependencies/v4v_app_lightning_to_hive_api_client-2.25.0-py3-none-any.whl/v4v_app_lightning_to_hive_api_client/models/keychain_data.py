from typing import Any, Dict, List, Type, TypeVar, Union

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..models.hive_keys import HiveKeys
from ..types import UNSET, Unset

T = TypeVar("T", bound="KeychainData")


@_attrs_define
class KeychainData:
    """Represents keychain data for authentication.

    Attributes:
        type (str, optional): The type of keychain data.
        username (str): The username associated with the keychain data.
        message (str): The message associated with the keychain data.
        method (str, optional): The authentication method.
        rpc (str, optional): The RPC (Remote Procedure Call) associated
            with the keychain data.
        title (str, optional): The title of the keychain data.
        key (HiveKeys, optional): The Hive key associated with the keychain data.
        domain (str, optional): The domain associated with the keychain data.

        Attributes:
            username (str):
            message (str):
            type (Union[Unset, str]):
            method (Union[Unset, str]):
            rpc (Union[Unset, str]):
            title (Union[Unset, str]):
            key (Union[Unset, HiveKeys]): An enumeration. Default: HiveKeys.POSTING.
            domain (Union[Unset, str]):
    """

    username: str
    message: str
    type: Union[Unset, str] = UNSET
    method: Union[Unset, str] = UNSET
    rpc: Union[Unset, str] = UNSET
    title: Union[Unset, str] = UNSET
    key: Union[Unset, HiveKeys] = HiveKeys.POSTING
    domain: Union[Unset, str] = UNSET
    additional_properties: Dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        username = self.username

        message = self.message

        type = self.type

        method = self.method

        rpc = self.rpc

        title = self.title

        key: Union[Unset, str] = UNSET
        if not isinstance(self.key, Unset):
            key = self.key.value

        domain = self.domain

        field_dict: Dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "username": username,
                "message": message,
            }
        )
        if type is not UNSET:
            field_dict["type"] = type
        if method is not UNSET:
            field_dict["method"] = method
        if rpc is not UNSET:
            field_dict["rpc"] = rpc
        if title is not UNSET:
            field_dict["title"] = title
        if key is not UNSET:
            field_dict["key"] = key
        if domain is not UNSET:
            field_dict["domain"] = domain

        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        d = src_dict.copy()
        username = d.pop("username")

        message = d.pop("message")

        type = d.pop("type", UNSET)

        method = d.pop("method", UNSET)

        rpc = d.pop("rpc", UNSET)

        title = d.pop("title", UNSET)

        _key = d.pop("key", UNSET)
        key: Union[Unset, HiveKeys]
        if isinstance(_key, Unset):
            key = UNSET
        else:
            key = HiveKeys(_key)

        domain = d.pop("domain", UNSET)

        keychain_data = cls(
            username=username,
            message=message,
            type=type,
            method=method,
            rpc=rpc,
            title=title,
            key=key,
            domain=domain,
        )

        keychain_data.additional_properties = d
        return keychain_data

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
