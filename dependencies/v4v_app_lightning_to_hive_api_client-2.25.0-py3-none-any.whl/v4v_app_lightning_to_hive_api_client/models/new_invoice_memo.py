from typing import Any, Dict, List, Type, TypeVar, Union

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..models.lnurl_currency import LnurlCurrency
from ..types import UNSET, Unset

T = TypeVar("T", bound="NewInvoiceMemo")


@_attrs_define
class NewInvoiceMemo:
    """NewInvoice base data model

    ### Critical difference:
    * `NewInvoiceBasic` is a base model which uses *sats* for the `amount`

    * ` NewInvoiceLnurlp` is a derived model which uses *milisats* for `amount`.

        Attributes:
            hive_accname (str): Must be a valid Hive name according to regex
            amount (Union[Unset, int]): Invoice amount in **sats** NOT **milisats** Default: 0.
            app_name (Union[Unset, str]): Can't have the value `string` Default: ''.
            testing (Union[Unset, bool]):  Default: False.
            expiry (Union[Unset, int]): Expiry time for the invoice in seconds. Max 600s Default: 300.
            memo (Union[Unset, str]): a formatted text memo which must include the following two elements:
                `hive_account_name | message to the hive user` Additionally if the memo includes `#HBD` then HBD will be sent,
                otherwise Hive is sent. Default: 'hive_accname | message'.
            currency (Union[Unset, LnurlCurrency]): Represents the available currencies for LNURL.

                Attributes:
                    hive (str): The currency code for Hive.
                    hbd (str): The currency code for HBD.
                    sats (str): The currency code for sats. Default: LnurlCurrency.HIVE.
    """

    hive_accname: str
    amount: Union[Unset, int] = 0
    app_name: Union[Unset, str] = ""
    testing: Union[Unset, bool] = False
    expiry: Union[Unset, int] = 300
    memo: Union[Unset, str] = "hive_accname | message"
    currency: Union[Unset, LnurlCurrency] = LnurlCurrency.HIVE
    additional_properties: Dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        hive_accname = self.hive_accname

        amount = self.amount

        app_name = self.app_name

        testing = self.testing

        expiry = self.expiry

        memo = self.memo

        currency: Union[Unset, str] = UNSET
        if not isinstance(self.currency, Unset):
            currency = self.currency.value

        field_dict: Dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "hive_accname": hive_accname,
            }
        )
        if amount is not UNSET:
            field_dict["amount"] = amount
        if app_name is not UNSET:
            field_dict["app_name"] = app_name
        if testing is not UNSET:
            field_dict["testing"] = testing
        if expiry is not UNSET:
            field_dict["expiry"] = expiry
        if memo is not UNSET:
            field_dict["memo"] = memo
        if currency is not UNSET:
            field_dict["currency"] = currency

        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        d = src_dict.copy()
        hive_accname = d.pop("hive_accname")

        amount = d.pop("amount", UNSET)

        app_name = d.pop("app_name", UNSET)

        testing = d.pop("testing", UNSET)

        expiry = d.pop("expiry", UNSET)

        memo = d.pop("memo", UNSET)

        _currency = d.pop("currency", UNSET)
        currency: Union[Unset, LnurlCurrency]
        if isinstance(_currency, Unset):
            currency = UNSET
        else:
            currency = LnurlCurrency(_currency)

        new_invoice_memo = cls(
            hive_accname=hive_accname,
            amount=amount,
            app_name=app_name,
            testing=testing,
            expiry=expiry,
            memo=memo,
            currency=currency,
        )

        new_invoice_memo.additional_properties = d
        return new_invoice_memo

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
