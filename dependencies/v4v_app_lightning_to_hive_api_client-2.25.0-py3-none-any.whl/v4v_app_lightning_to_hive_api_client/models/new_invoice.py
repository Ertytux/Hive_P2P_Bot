from typing import Any, Dict, List, Type, TypeVar, Union

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..models.lnurl_currency import LnurlCurrency
from ..types import UNSET, Unset

T = TypeVar("T", bound="NewInvoice")


@_attrs_define
class NewInvoice:
    """NewInvoice base data model

    ### Critical difference:
    * `NewInvoiceBasic` is a base model which uses *sats* for the `amount`

    * ` NewInvoiceLnurlp` is a derived model which uses *milisats* for `amount`.

        Attributes:
            hive_accname (str): Must be a valid Hive name according to regex
            amount (Union[Unset, int]): Invoice amount in **sats** NOT **milisats** Default: 0.
            app_name (Union[Unset, str]): Can't have the value `string` Default: ''.
            testing (Union[Unset, bool]):  Default: False.
            expiry (Union[Unset, int]): Expiry time for the invoice in seconds. Max 600s Default: 300.
            message (Union[Unset, str]):  Default: ''.
            hbd (Union[Unset, bool]):  Default: False.
            currency (Union[Unset, LnurlCurrency]): Represents the available currencies for LNURL.

                Attributes:
                    hive (str): The currency code for Hive.
                    hbd (str): The currency code for HBD.
                    sats (str): The currency code for sats. Default: LnurlCurrency.HIVE.
            clean_message (Union[Unset, bool]): If True and in conjunction with separate hive_accname and message the
                ultimate message sent via Hive will ONLY have the contents of the message field. In normal circumstances this
                message starts with the text 'You have received ... sats converted to Hive'. Default: False.
    """

    hive_accname: str
    amount: Union[Unset, int] = 0
    app_name: Union[Unset, str] = ""
    testing: Union[Unset, bool] = False
    expiry: Union[Unset, int] = 300
    message: Union[Unset, str] = ""
    hbd: Union[Unset, bool] = False
    currency: Union[Unset, LnurlCurrency] = LnurlCurrency.HIVE
    clean_message: Union[Unset, bool] = False
    additional_properties: Dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        hive_accname = self.hive_accname

        amount = self.amount

        app_name = self.app_name

        testing = self.testing

        expiry = self.expiry

        message = self.message

        hbd = self.hbd

        currency: Union[Unset, str] = UNSET
        if not isinstance(self.currency, Unset):
            currency = self.currency.value

        clean_message = self.clean_message

        field_dict: Dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "hive_accname": hive_accname,
            }
        )
        if amount is not UNSET:
            field_dict["amount"] = amount
        if app_name is not UNSET:
            field_dict["app_name"] = app_name
        if testing is not UNSET:
            field_dict["testing"] = testing
        if expiry is not UNSET:
            field_dict["expiry"] = expiry
        if message is not UNSET:
            field_dict["message"] = message
        if hbd is not UNSET:
            field_dict["hbd"] = hbd
        if currency is not UNSET:
            field_dict["currency"] = currency
        if clean_message is not UNSET:
            field_dict["clean_message"] = clean_message

        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        d = src_dict.copy()
        hive_accname = d.pop("hive_accname")

        amount = d.pop("amount", UNSET)

        app_name = d.pop("app_name", UNSET)

        testing = d.pop("testing", UNSET)

        expiry = d.pop("expiry", UNSET)

        message = d.pop("message", UNSET)

        hbd = d.pop("hbd", UNSET)

        _currency = d.pop("currency", UNSET)
        currency: Union[Unset, LnurlCurrency]
        if isinstance(_currency, Unset):
            currency = UNSET
        else:
            currency = LnurlCurrency(_currency)

        clean_message = d.pop("clean_message", UNSET)

        new_invoice = cls(
            hive_accname=hive_accname,
            amount=amount,
            app_name=app_name,
            testing=testing,
            expiry=expiry,
            message=message,
            hbd=hbd,
            currency=currency,
            clean_message=clean_message,
        )

        new_invoice.additional_properties = d
        return new_invoice

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
